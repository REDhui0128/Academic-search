# Validation

Use Python 3.10 or later in an isolated environment. From the skill directory:

```sh
python -m pip install -r requirements-test.txt
python -m pytest tests mcp-server/tests -q
```

The shared-engine regression suite mocks HTTP calls and covers identifier
normalization, conservative and transitive deduplication, version retention,
per-source counts, cursor pagination, request limits, redaction, JATS identities,
PDF status, Unpaywall/CORE response handling, and CLI output compatibility.
The MCP suite checks tool dispatch, schema exposure, and error handling.
Configuration tests use synthetic credentials and isolated working folders to
check `.env` parsing/priority, legacy SDK compatibility, key rotation, temporary
file cleanup, credential-safe errors, and the bounded Scopus view fallback.
Recovery regressions cover numeric/date Retry-After values, bounded Semantic
Scholar backoff, shared cooldowns, credential-safe request evidence, bulk fallback
accounting, comparison signs in metadata, arXiv query preservation and Scopus
view-specific first-page limits. Simulated rate limits verify recovery behavior;
a live successful request alone does not exercise a 429 recovery path.

The five existing Elsevier live tests are skipped by default. They require
valid credentials in the environment, project `.env`, or pybliometrics settings,
and explicit opt-in using
`NATURE_ACADEMIC_SEARCH_LIVE_ELSEVIER=1`. A skipped live test is not a passed
connectivity or entitlement check.

For the Codex skill metadata validator, install PyYAML from the test requirements
and invoke the validator with `python -X utf8` so Chinese descriptions also work
under Windows locales. This does not change retrieval runtime requirements.

Live observations on 2026-10-03: OpenAlex, Crossref, PubMed, Europe PMC, arXiv, and
Semantic Scholar returned structured search results. Semantic Scholar quick
search also returned intermittent HTTP 429; bulk search succeeded. Three
Crossref pages produced six distinct records. PMC JATS and an explicitly
versioned arXiv PDF were retrieved and parsed. The PDF identity check matched
front matter; publisher-version completeness remains unverified.

The earlier v2.1.1 validation process had not loaded the project's `.env`, so
credential-dependent Elsevier, Unpaywall and CORE full-text paths were not
validated in that run. CORE metadata lookup returned a structured response.
Live observations describe this run only, not guaranteed future availability.

v2.1.3 live checks on 2026-10-04: keyed Semantic Scholar relevance search returned
two records with HTTP 200. Bulk search returned 1,000 records, retaining two under
the requested budget and marking coverage partial. The native arXiv journal
query returned a record, and an OpenAlex/Crossref/arXiv combined search returned
records from all three sources. This run did not trigger a live 429; recovery
branches were exercised with simulated responses, including long cooldowns.
