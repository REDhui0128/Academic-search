"""Offline regression tests. HTTP calls are mocked; no API credentials required."""
import copy
import importlib
import json
import socket
import urllib.error
from unittest.mock import MagicMock

import pytest

from literature import fulltext, records, transport
from literature.search import Page, fetch_page, normalize_crossref

search_module = importlib.import_module("literature.search")


def paper(source="crossref", number=1, **fields):
    return records.record(source, **{"title": f"Wafer geometry study {number}",
        "authors": ["Alice Smith"], "year": 2025, "doi": f"10.1234/paper{number}", **fields})


@pytest.mark.parametrize("value,kind,expected", [
    ("https://doi.org/10.1234/ABC", "auto", ("doi", "10.1234/abc")),
    ("DOI:10.1234/ABC", "auto", ("doi", "10.1234/abc")),
    ("PMID:123456", "auto", ("pmid", "123456")),
    ("pmcid:pmc1234", "auto", ("pmcid", "PMC1234")),
    ("1234", "pmcid", ("pmcid", "PMC1234")),
    ("https://arxiv.org/pdf/hep-th/9901001v2.pdf", "auto", ("arxiv", "hep-th/9901001v2")),
    ("arXiv:1706.03762v1", "auto", ("arxiv", "1706.03762v1")),
    ("https://openalex.org/W123", "auto", ("openalex", "W123")),
    ("S2:" + "a" * 40, "auto", ("s2", "a" * 40)),
])
def test_identifier_normalization(value, kind, expected):
    assert records.identifier(value, kind) == expected


@pytest.mark.parametrize("value", ["", "nonsense", "file:///tmp/article.pdf", "123abc", "10.123/example"])
def test_invalid_identifier(value):
    with pytest.raises(ValueError):
        records.identifier(value)


def test_merge_retains_authors_counts_and_sources():
    first = paper(cited_by_count=8)
    second = paper("openalex", authors=["Alice Smith", "Bob Wu"], cited_by_count=11,
                   abstract="A longer abstract", openalex_id="W123")
    merged = records.deduplicate([first, second])
    assert len(merged) == 1
    assert merged[0]["authors"] == ["Alice Smith", "Bob Wu"]
    assert {k: v["count"] for k, v in merged[0]["citation_counts"].items()} == {"crossref": 8, "openalex": 11}
    assert merged[0]["sources"] == ["crossref", "openalex"]
    assert first["authors"] == ["Alice Smith"]  # Do not mutate caller records.


def test_bridge_identifiers_merge_transitively():
    items = [paper("crossref", title="Short title"),
             paper("pubmed", doi="", pmid="123456", title="Expanded title"),
             paper("openalex", pmid="123456", openalex_id="W123")]
    result = records.deduplicate(items)
    assert len(result) == 1
    assert set(result[0]["sources"]) == {"crossref", "pubmed", "openalex"}


def test_conflicting_dois_remain_separate():
    result = records.deduplicate([paper(pmid="123456"), paper("pubmed", 2, pmid="123456")])
    assert len(result) == 2
    assert result[0]["related_versions"]


def test_preprint_and_publication_remain_separate():
    assert len(records.deduplicate([paper(), paper("arxiv", arxiv_id="1706.03762v1")])) == 2


def test_arxiv_versions_remain_separate_and_same_versions_merge():
    first = paper("arxiv", doi="", arxiv_id="1706.03762v1")
    second = paper("arxiv", doi="", arxiv_id="1706.03762v2")
    third = paper("semantic_scholar", doi="", arxiv_id="1706.03762v2", type="preprint")
    result = records.deduplicate([first, second, third])
    assert len(result) == 2
    assert set(result[1]["sources"]) == {"arxiv", "semantic_scholar"}


def test_missing_doi_title_fallback_requires_author_and_year():
    assert len(records.deduplicate([paper(), paper("openalex", doi="")])) == 1
    assert len(records.deduplicate([paper(), paper("openalex", doi="", authors=[])])) == 2
    assert len(records.deduplicate([paper(), paper("openalex", doi="", year=2024)])) == 2


def test_abstract_reconstruction_warns_on_gaps_and_collisions():
    value, notes = records.reconstruct_abstract({"Wafer": [0], "geometry": [2], "shape": [2]})
    assert value == "Wafer geometry shape"
    assert len(notes) == 2


def jats(body="<sec><title>Methods</title><p>x &lt; y and A &gt; B.</p></sec>", doi="10.1234/paper1"):
    return (f'<article xmlns="http://jats.nlm.nih.gov"><front><article-meta>'
            f'<article-id pub-id-type="doi">{doi}</article-id><article-id pub-id-type="pmc">123</article-id>'
            '<title-group><article-title>Wafer study</article-title></title-group>'
            f'</article-meta></front>{"<body>" + body + "</body>" if body else ""}</article>').encode()


def test_jats_sections_identity_and_math():
    result = records.parse_jats(jats(), {"doi": "10.1234/paper1", "pmcid": "PMC123"})
    assert result["status"] == "full_text_parsed"
    assert result["sections"] == ["Methods"]
    assert "x < y and A > B." in result["text"]


def test_jats_metadata_is_not_full_text():
    assert records.parse_jats(jats(body=""))["status"] == "metadata_only"


@pytest.mark.parametrize("expected", [{"doi": "10.1234/other"}, {"pmid": "999"}])
def test_jats_identity_mismatch(expected):
    with pytest.raises(transport.RetrievalError, match="identifiers"):
        records.parse_jats(jats(), expected)


@pytest.mark.parametrize("payload,kind", [(b"Rate exceeded.", "rate_limited"),
    (b'<!DOCTYPE x [<!ENTITY a "x">]><x>&a;</x>', "invalid_response"),
    (b"<html>broken", "invalid_response")])
def test_invalid_xml(payload, kind):
    with pytest.raises(transport.RetrievalError) as error:
        records.xml_root(payload)
    assert error.value.kind == kind


def test_crossref_collective_and_null_author_names():
    value = normalize_crossref({"title": ["Consortium study"], "DOI": "10.1234/ABC",
                              "author": [{"given": None, "family": "Smith"}, {"name": "Wafer Consortium"}]})
    assert value["authors"] == ["Smith", "Wafer Consortium"]


def test_arxiv_http_200_error_is_not_a_paper():
    client = MagicMock()
    client.get.return_value = (b"<feed><entry><title>Error</title><summary>Bad query</summary></entry></feed>", {}, "")
    with pytest.raises(transport.RetrievalError) as error:
        fetch_page("arxiv", "wafer", None, 1, client, {})
    assert error.value.kind == "query_error"


def test_arxiv_version_lookup_uses_id_list():
    client = MagicMock()
    client.get.return_value = (b'<feed><entry><id>http://arxiv.org/abs/1706.03762v1</id><title>Attention Is All You Need</title></entry></feed>', {}, "")
    result, errors = fulltext.lookup("1706.03762v1", client=client)
    assert result["arxiv_id"] == "1706.03762v1" and not errors
    assert client.get.call_args.args[1] == {"id_list": "1706.03762v1", "max_results": 1}


def test_arxiv_identity_requires_requested_version():
    value = paper("arxiv", arxiv_id="1706.03762v2")
    assert not fulltext._matches(value, {"arxiv_id": "1706.03762v1"})
    assert fulltext._matches(value, {"arxiv_id": "1706.03762"})


def fake_search(monkeypatch, handler, **options):
    monkeypatch.setattr(search_module, "fetch_page", handler)
    return search_module.search("wafer", client=transport.Client(20), **options)


def test_search_partial_source_failure_preserves_other_results(monkeypatch):
    def handler(source, *args):
        if source == "openalex":
            raise transport.RetrievalError("HTTP 429", "rate_limited")
        return Page([paper(source)], 1)
    result = fake_search(monkeypatch, handler, sources=["crossref", "openalex"])
    assert result["unique_count"] == 1
    assert not result["complete"]
    assert result["errors"][0]["kind"] == "rate_limited"


def test_comprehensive_cursor_pages(monkeypatch):
    calls = []
    def handler(source, query, state, *args):
        calls.append(state)
        return Page([paper(number=1 if state is None else 2)], 2, "page2" if state is None else None)
    result = fake_search(monkeypatch, handler, sources=["crossref"], mode="comprehensive")
    assert calls == [None, "page2"]
    assert result["complete"] and result["unique_count"] == 2


def test_crossref_opaque_cursor_can_repeat_while_rows_advance(monkeypatch):
    calls = []
    def handler(source, query, state, *args):
        calls.append(state)
        return Page([paper(number=len(calls))], 3, "constant-opaque-cursor")
    result = fake_search(monkeypatch, handler, sources=["crossref"], mode="comprehensive")
    assert result["unique_count"] == 3
    assert result["complete"]


@pytest.mark.parametrize("page,reason", [
    (Page([paper()], 5), "count_mismatch"),
    (Page([paper()], 2, "next", raw_count=2), "normalization_gap"),
    (Page([paper()], 20, "next"), "quick_limit"),
])
def test_coverage_never_claims_missing_records_complete(monkeypatch, page, reason):
    result = fake_search(monkeypatch, lambda *a: copy.deepcopy(page), sources=["crossref"])
    assert not result["complete"]
    assert result["source_counts"]["crossref"]["stop_reason"] == reason


def test_estimated_total_does_not_end_pagination(monkeypatch):
    calls = []
    def handler(*args):
        calls.append(1)
        return Page([paper("semantic_scholar", len(calls))], 1,
                    "next" if len(calls) == 1 else None, count_kind="estimate")
    result = fake_search(monkeypatch, handler, sources=["semantic_scholar"], mode="comprehensive")
    assert len(calls) == 2 and result["unique_count"] == 2


def test_repeated_page_terminates(monkeypatch):
    result = fake_search(monkeypatch, lambda *a: Page([paper()], 100, "same"),
                         sources=["crossref"], mode="comprehensive")
    assert result["source_counts"]["crossref"]["pages"] == 2
    assert result["source_counts"]["crossref"]["stop_reason"] == "repeated_page"


def test_cursor_page_size_is_stable_when_remaining_budget_shrinks(monkeypatch):
    sizes = []
    def handler(source, query, state, size, *args):
        sizes.append(size)
        offset = 0 if state is None else 100
        return Page([paper(number=offset + i) for i in range(size)], 1000, "next" + str(offset))
    result = fake_search(monkeypatch, handler, sources=["crossref"], mode="comprehensive", max_records=110)
    assert sizes == [100, 100]
    assert result["retained_count"] == 110 and not result["complete"]


def test_search_preserves_distinct_arxiv_versions(monkeypatch):
    def handler(source, query, state, *args):
        version = 1 if state is None else 2
        return Page([paper("arxiv", doi="", arxiv_id=f"1706.03762v{version}")], 2, 1 if version == 1 else None)
    result = fake_search(monkeypatch, handler, sources=["arxiv"], mode="comprehensive")
    assert result["unique_count"] == 2
    assert result["complete"]


def test_pubmed_elocation_doi_fallback():
    client = MagicMock()
    client.json.return_value = {"esearchresult": {"count": "1", "idlist": ["123456"]}}
    payload = b'<PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>123456</PMID><Article><ArticleTitle>Test</ArticleTitle><ELocationID EIdType="doi">10.1234/ABC</ELocationID></Article></MedlineCitation></PubmedArticle></PubmedArticleSet>'
    client.get.return_value = (payload, {}, "")
    assert fetch_page("pubmed", "test", None, 1, client, {}).records[0]["doi"] == "10.1234/abc"


def test_global_budget_and_source_specific_queries(monkeypatch):
    seen = {}
    def handler(source, query, *args):
        seen[source] = query
        return Page([paper(source, i) for i in range(6)], 100, "next")
    result = fake_search(monkeypatch, handler, sources=["crossref", "semantic_scholar"],
                         mode="comprehensive", max_records=3, source_queries={"crossref": "custom query"})
    assert result["retained_count"] == 3
    assert result["total"] == 200 and result["unique_count"] == 3
    assert not result["complete"] and seen["crossref"] == "custom query"


def test_rank_score_counts_each_source_once(monkeypatch):
    def handler(source, *args):
        return Page([paper(source, openalex_id="W123" if source == "openalex" else "")], 1)
    result = fake_search(monkeypatch, handler, sources=["crossref", "openalex"])
    assert result["unique_count"] == 1
    assert result["results"][0]["rank_score"] == pytest.approx(2 / 61)


def test_duplicate_records_from_one_source_do_not_double_rank(monkeypatch):
    rows = [paper("openalex", openalex_id="W123"), paper("openalex", openalex_id="W456")]
    result = fake_search(monkeypatch, lambda *a: Page(rows, 2), sources=["openalex"])
    assert result["unique_count"] == 1
    assert result["results"][0]["rank_score"] == pytest.approx(1 / 61)


@pytest.mark.parametrize("options", [{"mode": "wrong"}, {"limit": 0}, {"max_calls": 0},
    {"year_from": 20}, {"sources": ["unknown"]}, {"sort": "wrong"},
    {"sources": ["crossref"], "author_id": "A123"},
    {"sources": ["crossref"], "source_queries": {"arxiv": "cat:cs.AI"}}])
def test_invalid_search_options(options):
    with pytest.raises(ValueError):
        search_module.search("wafer", **options)


def http_response(payload=b"{}", url="https://example.org/paper"):
    response = MagicMock()
    response.__enter__.return_value = response
    response.read.return_value = payload
    response.status, response.headers, response.url = 200, {}, url
    return response


def test_transport_budget_redaction_and_size(monkeypatch):
    client = transport.Client(1, max_bytes=4)
    monkeypatch.setattr(client, "_pace", lambda *a: None)
    client._opener.open = MagicMock(return_value=http_response())
    client.get("https://example.org", {"api_key": "secret-value", "email": "private@example.org"})
    assert "secret-value" not in json.dumps(client.provenance)
    assert "private@example.org" not in json.dumps(client.provenance)
    with pytest.raises(transport.RetrievalError) as error:
        client.get("https://example.org")
    assert error.value.kind == "call_limit"
    client = transport.Client(1, max_bytes=4)
    monkeypatch.setattr(client, "_pace", lambda *a: None)
    client._opener.open = MagicMock(return_value=http_response(b"12345"))
    with pytest.raises(transport.RetrievalError) as error:
        client.get("https://example.org")
    assert error.value.kind == "size_limit"


@pytest.mark.parametrize("pause,expected_calls", [("0", 2), ("120", 1)])
def test_rate_limit_retry_is_bounded(monkeypatch, pause, expected_calls):
    client = transport.Client(4)
    monkeypatch.setattr(client, "_pace", lambda *a: None)
    monkeypatch.setattr(transport.time, "sleep", lambda *a: None)
    error = urllib.error.HTTPError("https://example.org", 429, "limit", {"Retry-After": pause}, None)
    client._opener.open = MagicMock(side_effect=[error, http_response()])
    if expected_calls == 1:
        with pytest.raises(transport.RetrievalError) as caught:
            client.get("https://example.org")
        assert caught.value.kind == "rate_limited"
    else:
        client.get("https://example.org")
    assert client.calls == expected_calls


@pytest.mark.parametrize("address", ["127.0.0.1", "192.168.1.1", "::1", "169.254.169.254"])
def test_private_full_text_hosts_rejected(monkeypatch, address):
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(0, 0, 0, "", (address, 443))])
    with pytest.raises(transport.RetrievalError) as caught:
        transport.public_url("https://example.org/paper")
    assert caught.value.kind == "invalid_url"


def configure_retrieval(monkeypatch, payload, candidates=None):
    report = {"paper": paper(), "status": "metadata_only", "errors": [], "skipped": [],
              "candidates": candidates or [{"source": "europepmc", "url": "https://example.org/full.xml", "kind": "jats"}]}
    monkeypatch.setattr(fulltext, "discover", lambda *a: copy.deepcopy(report))
    monkeypatch.setattr(transport.Client, "get", lambda *a, **k: (payload, {}, "https://example.org/full.xml"))


def test_retrieve_jats_saves_files_and_preserves_prior_run(monkeypatch, tmp_path):
    configure_retrieval(monkeypatch, jats())
    first = fulltext.retrieve("10.1234/paper1", tmp_path)
    second = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert first["status"] == second["status"] == "full_text_parsed"
    assert len(first["files"]) == 2
    assert set(first["files"]).isdisjoint(second["files"])
    assert first["identity_status"] == "identifier_verified"


@pytest.mark.parametrize("payload,kind", [(jats(body=""), "metadata_only"),
    (jats(doi="10.1234/wrong"), "identity_mismatch"), (b"<html>access denied</html>", "invalid_response")])
def test_retrieve_rejects_unusable_jats(monkeypatch, tmp_path, payload, kind):
    configure_retrieval(monkeypatch, payload)
    result = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert result["status"] != "full_text_parsed" and result["files"] == []
    assert result["errors"][0]["kind"] == kind


def test_pdf_without_readable_identity_requires_review(monkeypatch, tmp_path):
    configure_retrieval(monkeypatch, b"%PDF-1.4 mock", [{"source": "openalex", "url": "https://example.org/p.pdf", "kind": "pdf"}])
    monkeypatch.setattr(fulltext, "_pdf_text", lambda *a: ("Wafer abstract only", None))
    result = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert result["status"] == "pdf_downloaded" and result["identity_status"] == "requires_review"
    assert len(result["files"]) == 1


def test_pdf_url_returning_html_is_not_saved_as_pdf(monkeypatch, tmp_path):
    configure_retrieval(monkeypatch, b"<html>access denied</html>", [{"source": "openalex", "url": "https://example.org/p.pdf", "kind": "pdf"}])
    result = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert result["files"] == [] and result["errors"][0]["kind"] == "not_full_text"


def test_unpaywall_and_core_copy_discovery(monkeypatch):
    monkeypatch.setenv("UNPAYWALL_EMAIL", "test@example.invalid")
    monkeypatch.setenv("CORE_API_KEY", "mock-key")
    monkeypatch.setattr(fulltext, "lookup", lambda *a: (paper(), []))
    client = MagicMock(calls=0, provenance=[])
    def response(url, *args, **kwargs):
        if "unpaywall" in url:
            return {"doi": "10.1234/paper1", "best_oa_location": {"url_for_pdf": "https://example.org/open.pdf", "license": "cc-by", "version": "publishedVersion"}}
        if "openalex" in url:
            return {"doi": "10.1234/paper1", "locations": []}
        if "europepmc" in url:
            return {"resultList": {"result": []}}
        return {"results": [{"doi": "10.1234/paper1", "id": 123, "downloadUrl": "https://example.org/core.pdf"},
                            {"doi": "10.1234/other", "id": 456, "downloadUrl": "https://example.org/wrong.pdf"}]}
    client.json.side_effect = response
    result = fulltext.discover("10.1234/paper1", client=client)
    assert not result["errors"] and result["status"] == "oa_link_found"
    assert len(result["candidates"]) == 3
    assert {item["kind"] for item in result["candidates"]} == {"pdf", "core_text"}
    assert all("wrong" not in item["url"] for item in result["candidates"])
    assert result["candidates"][0]["license"] == "cc-by"


@pytest.mark.parametrize("content,expected", [("A valid article body. " * 50, "full_text_parsed"),
    ("Not available for public API " * 50, "metadata_only"), ("Abstract", "metadata_only")])
def test_core_full_text_and_unavailable_sentinel(monkeypatch, tmp_path, content, expected):
    configure_retrieval(monkeypatch, b"", [{"source": "core", "url": "https://api.core.ac.uk/v3/works/123", "kind": "core_text"}])
    monkeypatch.setenv("CORE_API_KEY", "mock-key")
    monkeypatch.setattr(transport.Client, "json", lambda *a, **k: {"doi": "10.1234/paper1", "fullText": content})
    result = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert result["status"] == expected
    assert bool(result["files"]) == (expected == "full_text_parsed")


def test_jats_failure_falls_back_to_pmc(monkeypatch, tmp_path):
    configure_retrieval(monkeypatch, b"", [
        {"source": "europepmc", "url": "https://example.org/missing.xml", "kind": "jats"},
        {"source": "pmc", "url": "https://example.org/efetch", "kind": "pmc_jats", "pmcid": "PMC123"}])
    def fetch(client, url, params=None, **kwargs):
        if url.endswith("missing.xml"):
            raise transport.RetrievalError("HTTP 404", "not_found")
        assert params["db"] == "pmc" and params["id"] == "123"
        return jats(), {}, url
    monkeypatch.setattr(transport.Client, "get", fetch)
    result = fulltext.retrieve("10.1234/paper1", tmp_path)
    assert result["status"] == "full_text_parsed" and result["source"] == "pmc"
    assert result["errors"][0]["kind"] == "not_found"


def test_legacy_cli_list_and_full_report(monkeypatch, capsys, tmp_path):
    import academic_search
    report = {"results": [paper(), paper(number=2)], "errors": None,
              "source_counts": {"openalex": {"complete": True}}, "unique_count": 2}
    captured = {}
    def handler(query, **kwargs):
        captured.update(kwargs)
        return copy.deepcopy(report)
    monkeypatch.setattr(academic_search, "shared_search", handler)
    path = tmp_path / "report.json"
    monkeypatch.setattr("sys.argv", ["academic_search.py", "wafer", "--limit", "1", "--report-file", str(path)])
    assert academic_search.main() == 0
    assert len(json.loads(capsys.readouterr().out)) == 1
    assert len(json.loads(path.read_text(encoding="utf-8"))["results"]) == 2
    assert captured["sources"] == ["openalex"]
