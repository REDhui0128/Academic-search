"""Credential loading and SDK compatibility checks using synthetic secrets."""

import pytest

from literature import configuration
from literature.configuration import environment_value, elsevier_settings
from literature.search import _elsevier_headers
from literature.transport import openalex_params, semantic_headers, setting


@pytest.fixture(autouse=True)
def isolate_legacy_file(monkeypatch):
    monkeypatch.setattr(configuration, "_configuration_path", lambda: None)


def write_env(tmp_path, content):
    path = tmp_path / ".env"
    path.write_text(content, encoding="utf-8-sig")
    return path


def test_project_env_covers_existing_providers(tmp_path):
    write_env(tmp_path, "OPENALEX_API_KEY=oa-key\nS2_API_KEY=s2-key\nNCBI_API_KEY=ncbi-key\n"
                        "ELSEVIER_API_KEY=elsevier-key\nCORE_API_KEY=core-key\nUNPAYWALL_EMAIL=test@example.invalid\n")
    assert openalex_params()["api_key"] == "oa-key"
    assert semantic_headers()["x-api-key"] == "s2-key"
    assert setting("NCBI_API_KEY") == "ncbi-key"
    assert _elsevier_headers()["X-ELS-APIKey"] == "elsevier-key"
    assert environment_value("CORE_API_KEY") == "core-key"
    assert environment_value("UNPAYWALL_EMAIL") == "test@example.invalid"


def test_environment_has_priority_and_file_is_not_exported(tmp_path, monkeypatch):
    import os
    write_env(tmp_path, "ELSEVIER_API_KEY=file-key\nCORE_API_KEY=file-core\n")
    monkeypatch.setenv("ELSEVIER_API_KEY", "process-key")
    assert environment_value("ELSEVIER_API_KEY") == "process-key"
    assert environment_value("CORE_API_KEY") == "file-core"
    assert "CORE_API_KEY" not in os.environ


def test_semantic_alias_process_environment_overrides_dotenv(tmp_path, monkeypatch):
    write_env(tmp_path, "S2_API_KEY=file-key\n")
    monkeypatch.setenv("SEMANTIC_SCHOLAR_API_KEY", "process-alias-key")
    assert semantic_headers()["x-api-key"] == "process-alias-key"


@pytest.mark.parametrize("content,expected", [
    ('export ELSEVIER_API_KEY="quoted-key" # comment\n', "quoted-key"),
    ("ELSEVIER_API_KEY='key#hash'\n", "key#hash"),
    ("ELSEVIER_API_KEY=plain # comment\n", "plain"),
    ('ELSEVIER_API_KEY="quote\\\"key"\n', 'quote"key'),
    ("ELSEVIER_API_KEY=${VARIABLE}\n", "${VARIABLE}"),
])
def test_dotenv_is_data_not_shell(tmp_path, content, expected):
    write_env(tmp_path, content + "HTTP_PROXY=http://bad.invalid\nPYTHONPATH=untrusted\n")
    assert environment_value("ELSEVIER_API_KEY") == expected
    assert set(configuration.dotenv_values()) == {"ELSEVIER_API_KEY"}


def test_explicit_file_works_from_mcp_directory(tmp_path, monkeypatch):
    path = write_env(tmp_path, "ELSEVIER_API_KEY=explicit-key\n")
    server = tmp_path / "server"
    server.mkdir()
    monkeypatch.chdir(server)
    assert not environment_value("ELSEVIER_API_KEY")  # No parent-directory traversal.
    monkeypatch.setenv("NATURE_ACADEMIC_SEARCH_ENV_FILE", str(path))
    assert environment_value("ELSEVIER_API_KEY") == "explicit-key"


def test_file_switch_and_edits_do_not_keep_prior_project_keys(tmp_path, monkeypatch):
    path = write_env(tmp_path, "ELSEVIER_API_KEY=old\n")
    assert environment_value("ELSEVIER_API_KEY") == "old"
    path.write_text("ELSEVIER_API_KEY=new-longer\n", encoding="utf-8")
    assert environment_value("ELSEVIER_API_KEY") == "new-longer"
    other = tmp_path / "other"
    other.mkdir()
    monkeypatch.chdir(other)
    assert not environment_value("ELSEVIER_API_KEY")


def test_bad_env_error_never_contains_secret(tmp_path):
    write_env(tmp_path, 'ELSEVIER_API_KEY="sensitive-test-value\n')
    with pytest.raises(ValueError) as caught:
        environment_value("ELSEVIER_API_KEY")
    assert "sensitive-test-value" not in str(caught.value)
    assert "line 1" in str(caught.value)


def test_missing_explicit_file_is_reported(tmp_path, monkeypatch):
    monkeypatch.setenv("NATURE_ACADEMIC_SEARCH_ENV_FILE", str(tmp_path / "missing.env"))
    with pytest.raises(ValueError, match="does not exist"):
        environment_value("ELSEVIER_API_KEY")


def write_legacy(tmp_path, monkeypatch):
    path = tmp_path / "legacy.cfg"
    path.write_text("[Authentication]\nAPIKey = legacy-key\nInstToken = legacy-token\n"
                    "[Requests]\nTimeout = 12\nRetries = 0\n[Directories]\n"
                    "[Proxy]\nhttps = http://user:proxy-secret@example.invalid\n", encoding="utf-8")
    monkeypatch.setattr(configuration, "_configuration_path", lambda: path)
    return path


def test_legacy_credentials_and_pair_override(tmp_path, monkeypatch):
    write_legacy(tmp_path, monkeypatch)
    assert elsevier_settings()[:2] == (["legacy-key"], ["legacy-token"])
    monkeypatch.setenv("ELSEVIER_API_KEY", "new-key")
    assert elsevier_settings()[:2] == (["new-key"], [])
    monkeypatch.setenv("ELSEVIER_INSTTOKEN", "new-token")
    assert elsevier_settings()[:2] == (["new-key"], ["new-token"])


def test_extra_tokens_rejected(monkeypatch):
    monkeypatch.setenv("ELSEVIER_API_KEY", "one-key")
    monkeypatch.setenv("ELSEVIER_INSTTOKEN", "token-one,token-two")
    with pytest.raises(ValueError, match="corresponding"):
        elsevier_settings()


def test_malformed_legacy_config_cannot_leak_in_traceback(tmp_path, monkeypatch):
    import traceback
    path = tmp_path / "invalid.cfg"
    path.write_text("ELSEVIER_API_KEY=private-test-secret\n", encoding="utf-8")
    monkeypatch.setattr(configuration, "_configuration_path", lambda: path)
    with pytest.raises(ValueError) as caught:
        elsevier_settings()
    assert "private-test-secret" not in "".join(traceback.format_exception(caught.value))


def test_sdk_env_only_initialization_keeps_credentials_off_disk(tmp_path, monkeypatch, capsys):
    import sources.elsevier_common as bridge
    from pybliometrics.utils.startup import get_keys, get_insttokens
    write_env(tmp_path, "ELSEVIER_API_KEY=sdk-secret\nELSEVIER_INSTTOKEN=sdk-token\n")
    monkeypatch.setattr(bridge, "_initialised", False)
    real_init = bridge.pybliometrics_init
    paths, contents = [], []
    def capture(**kwargs):
        paths.append(kwargs["config_path"])
        contents.append(kwargs["config_path"].read_text(encoding="utf-8"))
        real_init(**kwargs)
    monkeypatch.setattr(bridge, "pybliometrics_init", capture)
    bridge.ensure_pybliometrics_config("scopus")
    bridge.ensure_pybliometrics_config("sciencedirect")
    assert len(paths) == 1 and not paths[0].exists()
    assert "sdk-secret" not in contents[0] and "sdk-token" not in contents[0]
    assert get_keys() == ["sdk-secret"] and get_insttokens() == ["sdk-token"]
    assert not capsys.readouterr().out
    monkeypatch.setenv("ELSEVIER_API_KEY", "rotated-key")
    monkeypatch.setenv("ELSEVIER_INSTTOKEN", "rotated-token")
    bridge.ensure_pybliometrics_config("scopus")
    assert len(paths) == 2 and get_keys() == ["rotated-key"]


def test_sdk_preserves_legacy_settings_without_rewriting_file(tmp_path, monkeypatch):
    import sources.elsevier_common as bridge
    from pybliometrics.utils.startup import get_config, get_keys
    path = write_legacy(tmp_path, monkeypatch)
    before = path.read_bytes()
    monkeypatch.setattr(bridge, "_initialised", False)
    bridge.ensure_pybliometrics_config("scopus")
    assert path.read_bytes() == before
    assert get_keys() == ["legacy-key"]
    assert get_config().getint("Requests", "Timeout") == 12
    assert get_config().get("Proxy", "https") == "http://user:proxy-secret@example.invalid"


def test_old_elsevier_tool_uses_dotenv_and_preserves_output(tmp_path, monkeypatch):
    from sources import ScopusSource, ScienceDirectSource
    import sources.elsevier_common as bridge
    write_env(tmp_path, "ELSEVIER_API_KEY=tool-key\n")
    monkeypatch.setattr(bridge, "_initialised", False)
    payload = {"search-results": {"opensearch:totalResults": "1", "entry": [{"dc:title": "Sample",
               "prism:doi": "10.1234/test", "prism:coverDate": "2025-01-01"}]}}
    for cls in (ScopusSource, ScienceDirectSource):
        monkeypatch.setattr(cls, "_search_api", lambda *args, **kwargs: payload)
        result = cls().search("wafer", rows=1)
        assert result["total"] == 1 and result["results"][0]["doi"] == "10.1234/test"
        assert result["source"] in {"scopus", "sciencedirect"}


def test_sdk_exception_cannot_echo_credentials(tmp_path, monkeypatch):
    from sources import ScopusSource
    from utils.errors import DataSourceError
    write_env(tmp_path, "ELSEVIER_API_KEY=confidential-key\n")
    def fail(*args, **kwargs):
        raise RuntimeError("URL contains confidential-key")
    monkeypatch.setattr(ScopusSource, "_search_api", fail)
    with pytest.raises(DataSourceError) as caught:
        ScopusSource().search("test")
    assert "confidential-key" not in str(caught.value)
    assert "RuntimeError" in str(caught.value)


@pytest.mark.parametrize("status", [401, 403])
def test_default_scopus_view_falls_back_and_reports_reduced_metadata(tmp_path, monkeypatch, status):
    from sources import ScopusSource
    from pybliometrics.exception import Scopus401Error, Scopus403Error
    write_env(tmp_path, "ELSEVIER_API_KEY=tool-key\n")
    calls = []
    def search_api(api, params):
        calls.append(params["view"])
        if params["view"] == "COMPLETE":
            raise {401: Scopus401Error, 403: Scopus403Error}[status]("private-response")
        return {"search-results": {"opensearch:totalResults": "1", "entry": [{"dc:title": "Sample"}]}}
    monkeypatch.setattr(ScopusSource, "_search_api", staticmethod(search_api))
    result = ScopusSource().search("test", rows=1)
    assert calls == ["COMPLETE", "STANDARD"]
    assert result["requested_view"] == "COMPLETE" and result["effective_view"] == "STANDARD"
    assert result["total"] == 1 and "omit abstract" in result["notes"][0]


@pytest.mark.parametrize("view,status", [("COMPLETE", 401), ("STANDARD", 403), (None, 429)])
def test_scopus_preserves_explicit_view_and_does_not_fallback_on_quota(tmp_path, monkeypatch, view, status):
    from sources import ScopusSource
    from utils.errors import DataSourceError
    from pybliometrics.exception import Scopus401Error, Scopus403Error, Scopus429Error
    write_env(tmp_path, "ELSEVIER_API_KEY=tool-key\n")
    calls = []
    def search_api(api, params):
        calls.append(params["view"])
        raise {401: Scopus401Error, 403: Scopus403Error, 429: Scopus429Error}[status]("tool-key")
    monkeypatch.setattr(ScopusSource, "_search_api", staticmethod(search_api))
    with pytest.raises(DataSourceError) as caught:
        ScopusSource().search("test", view=view)
    assert len(calls) == 1
    assert f"HTTP {status}" in str(caught.value) and "tool-key" not in str(caught.value)
