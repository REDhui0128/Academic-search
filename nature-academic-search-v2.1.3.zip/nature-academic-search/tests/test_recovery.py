"""Regression coverage for rate-limit recovery and the reviewed metadata edges."""
import importlib
import json
import urllib.error
from unittest.mock import MagicMock

import pytest

from literature import records, transport
from literature.search import arxiv_query, fetch_page, normalize_semantic
from sources.scopus import ScopusSource

search_module = importlib.import_module("literature.search")


@pytest.mark.parametrize("original,expected", [
    ("The model assumes x < y and z > w.", "The model assumes x < y and z > w."),
    ("p<0.05 and n>10", "p<0.05 and n>10"),
    ("x<y and z>w", "x<y and z>w"),
    ("x &lt; y and z &gt; w", "x < y and z > w"),
    ("<jats:p>p &lt; 0.05; n &gt; 10</jats:p>", "p < 0.05; n > 10"),
    ("<p>A <i>method</i> &amp; B.</p>", "A method & B."),
    ("<p title='x > y'>Data</p><br/>end", "Data end"),
    ("A<sup>2</sup>", "A 2"),
    ("A & B", "A & B"),
])
def test_metadata_text_preserves_math(original, expected):
    assert records.text(original) == expected
    assert normalize_semantic({"abstract": original})["abstract"] == expected


def test_xml_to_record_preserves_decoded_comparisons():
    root = records.xml_root(b"<AbstractText>x &lt; y and z &gt; w</AbstractText>")
    assert records.record("pubmed", abstract=records.text(root))["abstract"] == "x < y and z > w"


@pytest.mark.parametrize("query", ['jr:"Physical Review"', 'co:wafer', 'rn:ABC-123',
                                   'au:smith AND (ti:wafer OR abs:substrate)',
                                   'submittedDate:[202401010000 TO 202512312359]'])
def test_arxiv_native_queries_are_unchanged(query):
    assert arxiv_query(query) == query


@pytest.mark.parametrize("query,expected", [
    ('wafer OR substrate', 'all:wafer OR all:substrate'),
    ('"finite element" wafer', 'all:"finite element" AND all:wafer'),
    ('wafer (warpage OR deformation)', 'all:wafer AND ( all:warpage OR all:deformation )'),
    ('wafer AND NOT substrate', 'all:wafer ANDNOT all:substrate'),
    ('wafer NOT substrate', 'all:wafer ANDNOT all:substrate'),
    ('wafer ANDNOT substrate', 'all:wafer ANDNOT all:substrate'),
    ('(wafer OR substrate) warpage', '( all:wafer OR all:substrate ) AND all:warpage'),
])
def test_arxiv_plain_boolean_query(query, expected):
    assert arxiv_query(query) == expected


@pytest.mark.parametrize("query", ['"wafer', '(wafer', 'wafer OR', 'NOT wafer', 'wafer AND ()'])
def test_arxiv_invalid_queries_are_not_silently_rewritten(query):
    with pytest.raises(transport.RetrievalError) as caught:
        arxiv_query(query)
    assert caught.value.kind == "query_error"


def test_explicit_arxiv_source_query_bypasses_translation():
    client = MagicMock()
    client.get.return_value = (b"<feed><totalResults>0</totalResults></feed>", {}, "")
    search_module.search("wafer", sources=["arxiv"], source_queries={"arxiv": "custom:native"}, client=client)
    assert client.get.call_args.args[1]["search_query"] == "custom:native"


@pytest.mark.parametrize("view,expected", [(None, 25), ("COMPLETE", 25), ("COMPONENT", 25), ("STANDARD", 50)])
def test_scopus_first_page_cap_is_view_specific(monkeypatch, view, expected):
    source = ScopusSource()
    monkeypatch.setattr(source, "_run", lambda operation, callback: callback())
    request = MagicMock(return_value={"search-results": {"opensearch:totalResults": "0", "entry": []}})
    monkeypatch.setattr(source, "_search_api", request)
    result = source.search("TITLE(wafer)", rows=50, view=view)
    assert request.call_args.args[1]["count"] == expected
    if expected == 25:
        assert result["effective_rows"] == 25 and result["requested_rows"] == 50 and result["notes"]


def test_scopus_standard_fallback_restores_requested_page_size(monkeypatch):
    from pybliometrics.exception import Scopus401Error
    source = ScopusSource()
    monkeypatch.setattr(source, "_run", lambda operation, callback: callback())
    request = MagicMock(side_effect=[Scopus401Error("denied"), {"search-results": {"entry": []}}])
    monkeypatch.setattr(source, "_search_api", request)
    result = source.search("TITLE(wafer)", rows=50)
    assert [c.args[1]["count"] for c in request.call_args_list] == [25, 50]
    assert result["effective_view"] == "STANDARD"


class Clock:
    def __init__(self):
        self.now = 0.0
        self.sleeps = []

    def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.now += seconds


def fake_clock(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(transport.time, "monotonic", lambda: clock.now)
    monkeypatch.setattr(transport.time, "sleep", clock.sleep)
    return clock


def response(data):
    result = MagicMock()
    result.__enter__.return_value = result
    result.read.return_value = json.dumps(data).encode()
    result.status, result.headers = 200, {}
    result.url = "https://api.semanticscholar.org/graph/v1/paper/search"
    return result


def limited(pause=None):
    return urllib.error.HTTPError("https://api.semanticscholar.org/graph/v1/paper/search", 429, "limit",
                                 {"Retry-After": pause} if pause is not None else {}, None)


def test_semantic_backoff_and_safe_credential_evidence(monkeypatch):
    clock = fake_clock(monkeypatch)
    client = transport.Client(4)
    client._opener.open = MagicMock(side_effect=[limited(), limited(), response({"data": []})])
    client.json("https://api.semanticscholar.org/graph/v1/paper/search", headers={"x-api-key": "private-key"})
    assert client.calls == 3 and clock.sleeps == [5, 10]
    assert all(entry["api_key_sent"] for entry in client.provenance)
    assert "private-key" not in json.dumps(client.provenance)


@pytest.mark.parametrize("value,expected", [("0", 0), ("120", 120), ("-2", 0), ("NaN", 5), ("bad", 5)])
def test_retry_after_values(value, expected):
    assert transport.retry_delay({"retry-after": value}, 5) == expected


def test_retry_after_http_date(monkeypatch):
    monkeypatch.setattr(transport.time, "time", lambda: 1445412460)
    assert transport.retry_delay({"Retry-After": "Wed, 21 Oct 2015 07:28:00 GMT"}, 5) == 20


def test_long_cooldown_blocks_retries_fallback_and_other_clients(monkeypatch):
    clock = fake_clock(monkeypatch)
    client = transport.Client(6)
    client._opener.open = MagicMock(side_effect=limited("120"))
    with pytest.raises(transport.RetrievalError) as caught:
        fetch_page("semantic_scholar", "wafer", None, 2, client, {})
    assert caught.value.retry_after == 120
    assert client.calls == 1 and not clock.sleeps
    other = transport.Client(6)
    other._opener.open = MagicMock()
    with pytest.raises(transport.RetrievalError):
        other.json("https://api.semanticscholar.org/graph/v1/paper/search/bulk")
    assert other.calls == 0 and not other._opener.open.called


def test_quick_bulk_recovery_preserves_key_fields_and_record_limit(monkeypatch):
    fake_clock(monkeypatch)
    monkeypatch.setenv("S2_API_KEY", "synthetic-key")
    data = {"total": 10000, "token": "continuation", "data": [
        {"paperId": f"{i:040x}", "title": f"Wafer study {i}", "abstract": "x < y and z > w", "year": 2025}
        for i in range(12)]}
    client = transport.Client(4)
    client._opener.open = MagicMock(side_effect=[limited("0"), limited("0"), limited("0"), response(data)])
    report = search_module.search("wafer", sources=["semantic_scholar"], limit=2, client=client)
    assert report["result_count"] == 2 and report["retrieved_count"] == 12
    assert not report["complete"] and not report["errors"]
    stat = report["source_counts"]["semantic_scholar"]
    assert stat["retrieval_method"] == "bulk_after_429" and stat["count_kind"] == "estimate" and stat["notes"]
    assert stat["stop_reason"] == "quick_limit"
    for call in client._opener.open.call_args_list:
        assert call.args[0].get_header("X-api-key") == "synthetic-key"
    assert "/paper/search/bulk?" in client._opener.open.call_args.args[0].full_url
    assert client.calls == 4


@pytest.mark.parametrize("error,query", [(transport.RetrievalError("denied", "authentication", 401), "wafer"),
                                       (transport.RetrievalError("busy", "rate_limited", 429), 'wafer | substrate')])
def test_semantic_recovery_does_not_change_restricted_or_complex_requests(error, query):
    client = MagicMock()
    client.json.side_effect = error
    with pytest.raises(transport.RetrievalError):
        fetch_page("semantic_scholar", query, None, 2, client, {})
    assert client.json.call_count == 1


def test_semantic_request_budget_still_bounds_recovery(monkeypatch):
    fake_clock(monkeypatch)
    client = transport.Client(1)
    client._opener.open = MagicMock(side_effect=limited("0"))
    report = search_module.search("wafer", sources=["semantic_scholar"], client=client)
    assert client.calls == 1 and report["result_count"] == 0
    assert report["errors"][0]["kind"] == "call_limit"


def test_unavailable_cooldown_does_not_become_a_false_429(monkeypatch):
    fake_clock(monkeypatch)
    client = transport.Client(4)
    client._opener.open = MagicMock(side_effect=urllib.error.HTTPError(
        "https://example.org", 503, "unavailable", {"Retry-After": "120"}, None))
    for _ in range(2):
        with pytest.raises(transport.RetrievalError) as caught:
            client.get("https://example.org")
        assert caught.value.status == 503 and caught.value.kind == "unavailable"
    assert client.calls == 1
