"""MCP dispatch tests for academic_search_server tools."""

from __future__ import annotations

import asyncio
import json

import pytest


def _call_tool_json(tool_name: str, arguments: dict) -> dict:
    from academic_search_server import mcp

    content, _metadata = asyncio.run(mcp.call_tool(tool_name, arguments))
    return json.loads(content[0].text)


def test_search_papers_mcp_dispatch_uses_default_sources(monkeypatch):
    import academic_search_server

    captured = {}

    async def fake_search_all(query, sources, rows, filter_type, **options):
        assert options["mode"] == "quick"
        captured.update({
            "query": query,
            "sources": list(sources),
            "rows": rows,
            "filter_type": filter_type,
        })
        return {
            "total": 0,
            "sources_queried": list(sources),
            "result_count": 0,
            "results": [],
            "errors": None,
        }

    monkeypatch.setattr(academic_search_server, "_search_all", fake_search_all)

    payload = _call_tool_json("search_papers", {"query": "graphene", "rows": 100})

    assert payload["sources_queried"] == ["crossref", "pubmed", "arxiv"]
    assert "error" not in payload
    assert captured == {
        "query": "graphene",
        "sources": ["crossref", "pubmed", "arxiv"],
        "rows": 50,
        "filter_type": None,
    }


def test_search_papers_mcp_dispatch_accepts_elsevier_sources(monkeypatch):
    import academic_search_server

    captured = {}

    async def fake_search_all(query, sources, rows, filter_type, **options):
        assert options["mode"] == "quick"
        captured.update({
            "query": query,
            "sources": list(sources),
            "rows": rows,
            "filter_type": filter_type,
        })
        return {
            "total": 2,
            "sources_queried": list(sources),
            "result_count": 2,
            "results": [
                {"source": "scopus", "title": "Scopus result"},
                {"source": "sciencedirect", "title": "ScienceDirect result"},
            ],
            "errors": None,
        }

    monkeypatch.setattr(academic_search_server, "_search_all", fake_search_all)

    payload = _call_tool_json(
        "search_papers",
        {
            "query": "bridge scour",
            "sources": ["scopus", "sciencedirect"],
            "rows": 1,
            "type": "journal-article",
        },
    )

    assert payload["sources_queried"] == ["scopus", "sciencedirect"]
    assert {item["source"] for item in payload["results"]} == {
        "scopus",
        "sciencedirect",
    }
    assert captured == {
        "query": "bridge scour",
        "sources": ["scopus", "sciencedirect"],
        "rows": 1,
        "filter_type": "journal-article",
    }


@pytest.mark.parametrize("filter_type", [None, "journal-article"])
def test_search_error_handling_does_not_shadow_builtin_type(monkeypatch, filter_type):
    import academic_search_server
    async def fail(*args, **kwargs):
        raise RuntimeError("private provider details")
    monkeypatch.setattr(academic_search_server, "_search_all", fail)
    result = _call_tool_json("search_papers", {"query": "wafer", "type": filter_type})
    assert result == {"error": "Search failed (RuntimeError)"}


def test_search_auto_routing_and_new_options(monkeypatch):
    import academic_search_server
    captured = {}
    def fake(query, **kwargs):
        captured.update(kwargs)
        return {"results": [], "errors": None}
    monkeypatch.setattr(academic_search_server, "shared_search", fake)
    _call_tool_json("search_papers", {"query": "wafer", "sources": ["auto"], "mode": "comprehensive",
                    "domain": "engineering", "max_records": 120, "max_calls": 9,
                    "source_queries": {"arxiv": "all:wafer"}})
    assert captured["sources"] is None
    assert captured["mode"] == "comprehensive" and captured["domain"] == "engineering"
    assert captured["max_records"] == 120 and captured["max_calls"] == 9
    assert captured["source_queries"] == {"arxiv": "all:wafer"}


def test_full_text_tools_dispatch(monkeypatch):
    import academic_search_server
    monkeypatch.setattr(academic_search_server, "discover_full_text",
                        lambda identifier, kind, client: {"id": identifier, "id_type": kind, "budget": client.max_calls})
    assert _call_tool_json("find_full_text", {"id": "PMC123", "max_calls": 7}) == {
        "id": "PMC123", "id_type": "auto", "budget": 7}
    monkeypatch.setattr(academic_search_server, "retrieve_full_text",
                        lambda identifier, directory, kind, budget: {"id": identifier, "directory": directory, "budget": budget})
    assert _call_tool_json("fetch_full_text", {"id": "PMC123", "output_dir": "output", "max_calls": 8}) == {
        "id": "PMC123", "directory": "output", "budget": 8}


def test_new_tool_schemas_are_exposed():
    from academic_search_server import mcp
    tools = {tool.name: tool for tool in asyncio.run(mcp.list_tools())}
    assert {"search_papers", "find_full_text", "fetch_full_text", "get_paper_by_id", "get_citation"} <= tools.keys()
    assert {"mode", "source_queries", "max_calls"} <= tools["search_papers"].inputSchema["properties"].keys()
    assert "output_dir" in tools["fetch_full_text"].inputSchema["required"]
