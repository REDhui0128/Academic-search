# 统一学术搜索 MCP 服务器

这是统一的学术搜索 MCP 服务器，整合 OpenAlex、Semantic Scholar、Crossref、arXiv、PubMed、Europe PMC、Scopus 和 ScienceDirect 数据源。

## 工具

| 工具 | 功能 |
|------|------|
| `search_papers` | 统一搜索，支持多来源、分页与去重 |
| `get_paper_by_id` | 按 DOI、PMID 或 arXiv ID 获取详情 |
| `get_citation` | 格式化引用，支持 APA、Nature、IEEE 等风格 |
| `lookup_mesh` | MeSH 词表查询 |
| `search_scopus` | Scopus 高级检索 |
| `get_scopus_abstract` | Scopus 摘要与详情元数据 |
| `get_scopus_citation_overview` | Scopus 引用概览 |
| `search_scopus_authors` / `get_scopus_author` | 作者检索与详情 |
| `search_scopus_affiliations` / `get_scopus_affiliation` | 机构检索与详情 |
| `search_scopus_serial_titles` / `get_scopus_serial_title` | 期刊与连续出版物检索和详情 |
| `get_scopus_plumx_metrics` | PlumX 指标 |
| `search_sciencedirect` | ScienceDirect 检索 |
| `get_sciencedirect_article_metadata` | ScienceDirect 文章元数据 |

## 配置

环境变量：

- `PUBMED_EMAIL`：用于 NCBI 联系信息；建议配置真实邮箱。
- `NCBI_API_KEY`：可选，用于提升速率限制。
- Elsevier / Scopus / ScienceDirect：统一检索和专用工具均读取 `ELSEVIER_API_KEY`，可选 `ELSEVIER_INSTTOKEN`。环境变量优先，其次为项目 `.env`，最后兼容已有 `pybliometrics` 配置（如 `~/.config/pybliometrics.cfg`）。只有 `.env` 时，无需另建 SDK 密钥配置。
- 默认只读取工作目录中的 `.env`；若启动器切换目录，设置 `NATURE_ACADEMIC_SEARCH_ENV_FILE` 为项目 `.env` 的绝对路径。SDK 密钥仅在内存中传入，不写回配置文件。

`search_papers` 默认检索 CrossRef、PubMed 和 arXiv。Scopus / ScienceDirect 是可选 provider：只有在 `sources` 显式传入 `scopus` / `sciencedirect`，或调用专用 Scopus / ScienceDirect 工具时，才会访问 Elsevier API。

缺少密钥时，统一检索在 `errors` 中报告该来源错误，专用工具返回 `error`。
Scopus 专用搜索未指定 `view` 时，默认 COMPLETE 若返回 401/403，会重试一次 STANDARD，并在 `effective_view` 和 `notes` 中说明字段减少。显式要求 COMPLETE 时保留其权限错误。摘要、ScienceDirect、作者等接口的权限仍需分别验证。

配置文件：`config.toml`

## 使用

插件会通过以下形式启动隔离运行环境：

```bash
uv run --no-project --directory <mcp-server> --with ... python academic_search_server.py
```

`uv --directory` 会切换工作目录；应在 MCP 启动环境中设置
`NATURE_ACADEMIC_SEARCH_ENV_FILE`（例如 `D:\your-project\.env`）。已有服务需重新加载。

这些工具由 `nature-academic-search` skill 自带的 MCP 服务提供，专用 Elsevier 工具底层调用 `pybliometrics`。
