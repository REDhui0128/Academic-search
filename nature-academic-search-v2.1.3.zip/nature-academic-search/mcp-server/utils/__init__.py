"""Utility modules for academic search."""

import sys
from pathlib import Path

_shared_lib = Path(__file__).resolve().parents[2] / "lib"
if not _shared_lib.is_dir():
    _shared_lib = Path(__file__).resolve().parents[1] / "lib"
if str(_shared_lib) not in sys.path:
    sys.path.insert(0, str(_shared_lib))

from .config import Config, get_config
from .errors import AcademicSearchError, ConfigError, DataSourceError, TimeoutError
from .logging import setup_logging

__all__ = [
    "AcademicSearchError",
    "DataSourceError",
    "TimeoutError",
    "ConfigError",
    "setup_logging",
    "get_config",
    "Config",
]
