"""Academic search MCP server.

Unified entry point exposing multi-source search and source-specific tools for
CrossRef, PubMed, arXiv, Scopus, and ScienceDirect.
"""

from __future__ import annotations

import asyncio
import json
import re
import sys
from pathlib import Path
from typing import Any

from mcp.server import FastMCP

_shared_lib = Path(__file__).resolve().parents[1] / "lib"
if not _shared_lib.is_dir():
    _shared_lib = Path(__file__).resolve().parent / "lib"
sys.path.insert(0, str(_shared_lib))
from literature.search import search as shared_search
from literature.records import identifier as normalize_identifier
from literature.fulltext import discover as discover_full_text, retrieve as retrieve_full_text, lookup as lookup_metadata
from literature.transport import Client

from sources import (
    ArxivSource,
    CrossRefSource,
    PubMedSource,
    ScienceDirectSource,
    ScopusSource,
)
from utils import AcademicSearchError, DataSourceError, setup_logging

mcp = FastMCP("academic-search")
logger = setup_logging()

# Singleton source instances (shared across tool calls)
_crossref = CrossRefSource()
_pubmed = PubMedSource()
_arxiv = ArxivSource()
_scopus = ScopusSource()
_sciencedirect = ScienceDirectSource()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _detect_id_type(id: str) -> str:
    return normalize_identifier(id)[0]


def _resolve_id_type(id: str, id_type: str) -> str:
    return normalize_identifier(id, id_type)[0]


def _json_ok(data: Any) -> str:
    """Serialize a successful result to JSON string."""
    return json.dumps(data, ensure_ascii=False, indent=2)


def _json_error(message: str, source: str | None = None) -> str:
    """Serialize an error result to JSON string."""
    payload: dict[str, Any] = {"error": message}
    if source:
        payload["source"] = source
    return json.dumps(payload, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Async wrappers for synchronous sources
# ---------------------------------------------------------------------------

async def _search_crossref(query: str, rows: int, filter_type: str | None) -> dict:
    return await asyncio.to_thread(_crossref.search, query, rows, filter_type)


async def _search_pubmed(query: str, rows: int) -> dict:
    return await asyncio.to_thread(_pubmed.search, query, rows)


async def _search_arxiv(query: str, rows: int) -> dict:
    return await asyncio.to_thread(_arxiv.search, query, rows)


async def _search_scopus(query: str, rows: int) -> dict:
    return await asyncio.to_thread(_scopus.search, query, rows)


async def _search_sciencedirect(query: str, rows: int) -> dict:
    return await asyncio.to_thread(_sciencedirect.search, query, rows)


async def _search_all(query, sources, rows, filter_type, **options):
    return await asyncio.to_thread(shared_search, query, sources=sources, limit=rows,
                                   filter_type=filter_type, **options)


@mcp.tool()
async def search_papers(
    query: str,
    sources: list[str] | None = None,
    rows: int = 5,
    type: str | None = None,
    mode: str = "quick",
    max_records: int = 1000,
    max_calls: int = 50,
    year_from: int | None = None,
    sort: str = "relevance_score",
    domain: str = "general",
    source_queries: dict[str, str] | None = None,
) -> str:
    """Search, deduplicate and report retrieval coverage.

    Existing query/sources/rows/type arguments remain valid. Legacy default
    sources are Crossref/PubMed/arXiv. Pass sources=["auto"] for domain routing,
    or name openalex, semantic_scholar, crossref, arxiv, pubmed, europepmc,
    scopus, sciencedirect. Elsevier sources use existing credentials when selected.
    rows limits each source in quick mode. Comprehensive mode paginates within
    global max_records and max_calls. source_queries accepts source-native syntax.
    total is the overlapping sum of source hit counts; unique_count is the
    number of deduplicated retrieved records. Inspect complete/source_counts.
    """
    if sources is None:
        sources = ["crossref", "pubmed", "arxiv"]
    elif sources == ["auto"]:
        sources = None
    try:
        result = await _search_all(query, sources, max(1, min(rows, 50)), type,
                                   mode=mode, max_records=max_records, max_calls=max_calls,
                                   year_from=year_from, sort=sort, domain=domain,
                                   source_queries=source_queries)
        return _json_ok(result)
    except ValueError as exc:
        return _json_error(str(exc))
    except Exception as exc:
        return _json_error(f"Search failed ({exc.__class__.__name__})")


@mcp.tool()
def find_full_text(id: str, id_type: str = "auto", max_calls: int = 20) -> str:
    """Locate open copies without saving article files. Constructed JATS endpoints
    are unverified candidates. UNPAYWALL_EMAIL enables DOI OA lookup;
    CORE_API_KEY enables CORE full text. Missing credentials affect that source only.
    """
    try:
        return _json_ok(discover_full_text(id, id_type, Client(max_calls=max_calls)))
    except (ValueError, OSError) as exc:
        return _json_error(str(exc))


@mcp.tool()
def fetch_full_text(id: str, output_dir: str, id_type: str = "auto", max_calls: int = 30) -> str:
    """Retrieve open text/PDF into the requested directory. Return saved paths and
    actual content/identity status. pdf_downloaded requires review; it does not
    mean parsed full text. Use when the user requests retrieval/download/reading.
    """
    try:
        return _json_ok(retrieve_full_text(id, output_dir, id_type, max_calls))
    except (ValueError, OSError) as exc:
        return _json_error(str(exc))


@mcp.tool()
def search_scopus(
    query: str,
    rows: int = 5,
    view: str | None = None,
    subscriber: bool = True,
) -> str:
    """Search Scopus documents using a Scopus advanced-search query.

    Args:
        query: Scopus advanced search query.
        rows: Requested first-page results (max 50; COMPLETE/COMPONENT max 25,
            with requested_rows/effective_rows and notes when capped).
        view: Optional Scopus view ("STANDARD" or "COMPLETE"). Explicit views are
            honored. If the default COMPLETE view returns 401/403, retry once
            with STANDARD and report the reduced metadata in notes.
        subscriber: Select COMPLETE by default when true, STANDARD when false.
            This tool retrieves the first page only.
    """
    try:
        return _json_ok(_scopus.search(query, rows, view=view, subscriber=subscriber))
    except DataSourceError as exc:
        logger.error("search_scopus failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("search_scopus failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_abstract(
    identifier: str,
    id_type: str | None = None,
    view: str = "META_ABS",
) -> str:
    """Retrieve Scopus abstract metadata.

    Args:
        identifier: EID, Scopus ID, DOI, PMID, or PII.
        id_type: Optional pybliometrics ID type; auto-detected when omitted.
        view: Scopus abstract view, usually "META_ABS".
    """
    try:
        return _json_ok(_scopus.get_abstract(identifier, id_type=id_type, view=view))
    except DataSourceError as exc:
        logger.error("get_scopus_abstract failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_abstract failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_citation_overview(
    identifiers: list[str],
    id_type: str = "scopus_id",
    date: str | None = None,
    citation: str | None = None,
) -> str:
    """Retrieve Scopus citation overview for one or more documents.

    Args:
        identifiers: Document identifiers.
        id_type: Identifier type, e.g. "scopus_id", "doi", or "eid".
        date: Optional year range such as "2020-2025".
        citation: Optional exclusion mode, e.g. "exclude-self".
    """
    try:
        result = _scopus.get_citation_overview(
            identifiers,
            id_type=id_type,
            date=date,
            citation=citation,
        )
        return _json_ok(result)
    except DataSourceError as exc:
        logger.error("get_scopus_citation_overview failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_citation_overview failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def search_scopus_authors(query: str, rows: int = 5) -> str:
    """Search Scopus author profiles."""
    try:
        return _json_ok(_scopus.search_authors(query, rows))
    except DataSourceError as exc:
        logger.error("search_scopus_authors failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("search_scopus_authors failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_author(author_id: str, view: str = "ENHANCED") -> str:
    """Retrieve a Scopus author profile by author ID."""
    try:
        return _json_ok(_scopus.get_author(author_id, view=view))
    except DataSourceError as exc:
        logger.error("get_scopus_author failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_author failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def search_scopus_affiliations(query: str, rows: int = 5) -> str:
    """Search Scopus affiliations."""
    try:
        return _json_ok(_scopus.search_affiliations(query, rows))
    except DataSourceError as exc:
        logger.error("search_scopus_affiliations failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("search_scopus_affiliations failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_affiliation(affiliation_id: str, view: str = "STANDARD") -> str:
    """Retrieve a Scopus affiliation by affiliation ID."""
    try:
        return _json_ok(_scopus.get_affiliation(affiliation_id, view=view))
    except DataSourceError as exc:
        logger.error("get_scopus_affiliation failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_affiliation failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def search_scopus_serial_titles(
    title: str | None = None,
    issn: str | None = None,
    publisher: str | None = None,
    subject: str | None = None,
    subject_code: str | None = None,
    content: str | None = None,
    open_access: str | None = None,
    rows: int = 5,
    view: str = "ENHANCED",
) -> str:
    """Search Scopus serial titles.

    Args:
        title: Serial title query.
        issn: ISSN query.
        publisher: Publisher query.
        subject: Subject-area query.
        subject_code: Subject-area code query.
        content: Content type query.
        open_access: Open-access filter.
        rows: Number of results to return.
        view: Scopus serial title view.
    """
    query = {
        "title": title,
        "issn": issn,
        "pub": publisher,
        "subj": subject,
        "subjCode": subject_code,
        "content": content,
        "oa": open_access,
    }
    try:
        return _json_ok(_scopus.search_serial_titles(query, rows=rows, view=view))
    except DataSourceError as exc:
        logger.error("search_scopus_serial_titles failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("search_scopus_serial_titles failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_serial_title(
    issn: str,
    view: str = "ENHANCED",
    years: str | None = None,
) -> str:
    """Retrieve a Scopus serial title by ISSN."""
    try:
        return _json_ok(_scopus.get_serial_title(issn, view=view, years=years))
    except DataSourceError as exc:
        logger.error("get_scopus_serial_title failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_serial_title failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_scopus_plumx_metrics(identifier: str, id_type: str) -> str:
    """Retrieve PlumX metrics for a document identifier."""
    try:
        return _json_ok(_scopus.get_plumx_metrics(identifier, id_type))
    except DataSourceError as exc:
        logger.error("get_scopus_plumx_metrics failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_scopus_plumx_metrics failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def search_sciencedirect(
    query: str,
    rows: int = 5,
    view: str | None = None,
) -> str:
    """Search ScienceDirect article metadata."""
    try:
        return _json_ok(_sciencedirect.search(query, rows=rows, view=view))
    except DataSourceError as exc:
        logger.error("search_sciencedirect failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("search_sciencedirect failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_sciencedirect_article_metadata(
    query: str,
    rows: int = 5,
    view: str | None = None,
) -> str:
    """Retrieve ScienceDirect article metadata with a metadata API query."""
    try:
        result = _sciencedirect.get_article_metadata(query, rows=rows, view=view)
        return _json_ok(result)
    except DataSourceError as exc:
        logger.error("get_sciencedirect_article_metadata failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_sciencedirect_article_metadata failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


@mcp.tool()
def get_paper_by_id(id: str, id_type: str = "auto") -> str:
    """Get paper details by identifier (DOI, PMID, or arXiv ID).

    Args:
        id: Paper identifier. Auto-detected if id_type is "auto":
            - Starts with "10." -> DOI (CrossRef)
            - 7-8 digit number -> PMID (PubMed)
            - YYMM.NNNNN format -> arXiv ID (arXiv)
        id_type: Force identifier type ("doi", "pmid", "arxiv", or "auto").

    Returns:
        JSON string with detailed paper metadata.
    """
    if not id or not id.strip():
        return _json_error("Empty identifier")

    try:
        resolved_type, id = normalize_identifier(id, id_type)
    except ValueError as exc:
        return _json_error(str(exc))

    logger.info("get_paper_by_id called", extra={
        "tool": "get_paper_by_id",
        "id": id,
        "id_type": resolved_type,
    })

    try:
        if resolved_type == "doi":
            result = _crossref.get_by_doi(id.strip())
        elif resolved_type == "pmid":
            result = _pubmed.get_by_pmid(id.strip())
        elif resolved_type == "arxiv":
            result = _arxiv.get_by_id(id.strip())
        else:
            client = Client(max_calls=12)
            result, errors = lookup_metadata(id, resolved_type, client)
            result["retrieval_errors"] = errors
            result["provenance"] = client.provenance
    except DataSourceError as exc:
        logger.error("get_paper_by_id failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_paper_by_id failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")

    return _json_ok(result)


@mcp.tool()
def get_citation(id: str, id_type: str = "auto", style: str = "apa") -> str:
    """Get formatted citation for a paper.

    Uses CrossRef content negotiation for DOI-based citations.
    For PMID/arXiv IDs, fetches metadata first then generates a basic citation.

    Args:
        id: Paper identifier (DOI, PMID, or arXiv ID).
        id_type: Force identifier type ("doi", "pmid", "arxiv", or "auto").
        style: Citation style. Supported: apa, nature, ieee, harvard,
               vancouver, chicago, mla.

    Returns:
        JSON string with the formatted citation.
    """
    if not id or not id.strip():
        return _json_error("Empty identifier")

    try:
        resolved_type, id = normalize_identifier(id, id_type)
    except ValueError as exc:
        return _json_error(str(exc))

    logger.info("get_citation called", extra={
        "tool": "get_citation",
        "id": id,
        "id_type": resolved_type,
        "style": style,
    })

    try:
        if resolved_type == "doi":
            citation = _crossref.get_citation(id.strip(), style=style)
            return _json_ok({"id": id, "style": style, "citation": citation})

        # For non-DOI IDs, fetch metadata and build a basic citation
        if resolved_type == "pmid":
            paper = _pubmed.get_by_pmid(id.strip())
        elif resolved_type == "arxiv":
            paper = _arxiv.get_by_id(id.strip())
        else:
            return _json_error(f"Unsupported ID type: {resolved_type}")

        citation = _format_basic_citation(paper, style)
        return _json_ok({"id": id, "style": style, "citation": citation})

    except DataSourceError as exc:
        logger.error("get_citation failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("get_citation failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")


def _format_basic_citation(paper: dict, style: str) -> str:
    """Generate a basic citation string from unified paper metadata.

    This is a fallback for non-DOI papers where CrossRef content
    negotiation is not available.
    """
    authors = paper.get("authors", [])
    title = paper.get("title", "Untitled")
    year = paper.get("year", "n.d.")
    journal = paper.get("journal", "")
    doi = paper.get("doi", "")
    arxiv_id = paper.get("arxiv_id", "")
    pmid = paper.get("pmid", "")

    # Author formatting
    if len(authors) > 3:
        author_str = f"{authors[0]} et al."
    elif authors:
        author_str = ", ".join(authors)
    else:
        author_str = "Unknown"

    if style == "nature":
        parts = [f"{author_str}. {title}."]
        if journal:
            parts.append(f" *{journal}*.")
        if year:
            parts.append(f" ({year}).")
        if doi:
            parts.append(f" https://doi.org/{doi}")
        return "".join(parts)

    if style == "ieee":
        ref = f"{author_str}, \"{title}\""
        if journal:
            ref += f", *{journal}*"
        if year:
            ref += f", {year}"
        ref += "."
        if doi:
            ref += f" doi: {doi}."
        return ref

    # Default APA-like
    parts = [f"{author_str} ({year}). {title}."]
    if journal:
        parts.append(f" *{journal}*.")
    if doi:
        parts.append(f" https://doi.org/{doi}")
    elif arxiv_id:
        parts.append(f" arXiv:{arxiv_id}")
    elif pmid:
        parts.append(f" PMID:{pmid}")
    return "".join(parts)


@mcp.tool()
def lookup_mesh(term: str) -> str:
    """Lookup MeSH (Medical Subject Headings) terms.

    Queries the MeSH database via NCBI E-utilities to find matching
    descriptor names and unique IDs.

    Args:
        term: Search term to look up in the MeSH vocabulary.

    Returns:
        JSON string with matching MeSH descriptors.
    """
    if not term or not term.strip():
        return _json_error("Empty MeSH lookup term")

    logger.info("lookup_mesh called", extra={
        "tool": "lookup_mesh",
        "term": term,
    })

    try:
        result = _pubmed.lookup_mesh(term.strip())
    except DataSourceError as exc:
        logger.error("lookup_mesh failed: %s", exc)
        return _json_error(str(exc), source=exc.source)
    except Exception as exc:
        logger.exception("lookup_mesh failed unexpectedly")
        return _json_error(f"Unexpected error: {exc}")

    return _json_ok(result)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
