"""Shared helpers for pybliometrics-backed Elsevier sources."""

from __future__ import annotations

from configparser import ConfigParser
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import tempfile
from threading import RLock
from typing import Any

from pybliometrics import init as pybliometrics_init
from pybliometrics.utils.constants import DEFAULT_PATHS
from pybliometrics.utils.startup import get_config as sdk_config

from utils.errors import DataSourceError
from literature.configuration import elsevier_settings, environment_value


_init_lock = RLock()
_initialised = False
_fingerprint = None


def ensure_pybliometrics_config(source: str) -> None:
    """Initialize the SDK noninteractively; pass keys/tokens only in memory."""
    global _initialised, _fingerprint
    with _init_lock:
        try:
            keys, tokens, existing = elsevier_settings()
            if not keys:
                raise DataSourceError(source, "Set ELSEVIER_API_KEY in the environment/project .env, or configure pybliometrics")
            cache_override = environment_value("NATURE_ACADEMIC_SEARCH_CACHE_DIR")
            directories = {}
            for api, default in DEFAULT_PATHS.items():
                path = (Path(cache_override).expanduser() / api if cache_override else
                        Path(existing.get("Directories", api, fallback=str(default))).expanduser())
                directories[api] = str(path.resolve())
            settings = {section: dict(existing.items(section, raw=True)) for section in existing.sections()}
            fingerprint = hashlib.sha256(json.dumps([keys, tokens, settings, directories],
                                                    sort_keys=True).encode()).hexdigest()
            if _initialised and fingerprint == _fingerprint:
                return
            runtime = ConfigParser(interpolation=None)
            runtime.optionxform = str
            for section in ("Directories", "Authentication", "Requests"):
                runtime.add_section(section)
            for api, path in directories.items():
                runtime.set("Directories", api, path)
            for option, default in (("Timeout", "20"), ("Retries", "2")):
                runtime.set("Requests", option, existing.get("Requests", option, fallback=default))
            # The temporary file contains only paths and request settings. In
            # particular, SDK create_config() must never write the user's keys.
            config_path = None
            try:
                # Use the same platform encoding as pybliometrics' config reader.
                with tempfile.NamedTemporaryFile(mode="w", suffix=".cfg", delete=False) as handle:
                    config_path = Path(handle.name)
                    runtime.write(handle)
                pybliometrics_init(config_path=config_path, keys=keys, inst_tokens=tokens or None)
            finally:
                if config_path is not None:
                    config_path.unlink(missing_ok=True)
            # Preserve optional legacy settings, including proxy credentials,
            # exclusively in memory after the secret-free SDK initialization.
            current = sdk_config()
            for section in existing.sections():
                if section in {"Authentication", "Directories", "Requests"}:
                    continue
                if not current.has_section(section):
                    current.add_section(section)
                for name, value in existing.items(section, raw=True):
                    current.set(section, name, value)
            _initialised, _fingerprint = True, fingerprint
        except DataSourceError:
            raise
        except Exception as exc:
            # Configuration parser and HTTP exceptions can contain key values.
            raise DataSourceError(source, f"Elsevier configuration failed ({type(exc).__name__})") from None


@contextmanager
def elsevier_session(source):
    """Protect the SDK's process-global settings throughout each operation."""
    with _init_lock:
        ensure_pybliometrics_config(source)
        yield


def elsevier_error(source, operation, exc):
    """Give actionable error categories without echoing SDK response bodies."""
    name = type(exc).__name__
    hints = {
        "Scopus401Error": "HTTP 401: authentication or endpoint/view access rejected; check the key, institutional access or InstToken",
        "Scopus403Error": "HTTP 403: endpoint/view access denied; check institutional access or InstToken",
        "Scopus429Error": "HTTP 429: Elsevier quota or rate limit reached; retry after the limit resets",
        "Scopus400Error": "HTTP 400: check the source-specific query and view",
        "Scopus404Error": "HTTP 404: the requested record was not found",
        "Scopus407Error": "HTTP 407: the configured proxy requires authentication",
    }
    detail = hints.get(name, name)
    return DataSourceError(source, f"{operation} failed ({detail})")


def record_to_dict(value: Any) -> Any:
    """Recursively convert pybliometrics records into JSON-safe structures."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if hasattr(value, "_asdict"):
        return {k: record_to_dict(v) for k, v in value._asdict().items()}
    if isinstance(value, dict):
        return {str(k): record_to_dict(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [record_to_dict(v) for v in value]
    return value


def safe_attr(obj: Any, name: str) -> Any:
    """Read an optional pybliometrics property."""
    try:
        return getattr(obj, name)
    except (AttributeError, KeyError, TypeError):
        return None


def split_semicolon(value: str | None) -> list[str]:
    """Split pybliometrics semicolon-joined fields."""
    if not value:
        return []
    return [item.strip() for item in value.split(";") if item.strip()]


def year_from_date(value: str | None) -> int | None:
    """Extract a publication year from an ISO-like date string."""
    if not value or len(value) < 4:
        return None
    try:
        return int(value[:4])
    except ValueError:
        return None
