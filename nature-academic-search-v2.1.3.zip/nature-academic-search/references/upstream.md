# Upstream provenance

Upgrade designed against K-Dense Scientific Agent Skills, paper-lookup metadata
version 2.4 (last-reviewed 2026-09-30), inspected 2026-10-03.

Source: https://github.com/K-Dense-AI/scientific-agent-skills/tree/main/skills/paper-lookup

The upstream skill declares MIT licensing. Its pagination, JATS, arXiv and
OpenAlex parsing guidance informed this independently written implementation.
Upstream source files are not vendored verbatim. This record identifies the
reviewed version/date; the branch URL may change. Future direct code imports must
pin their revision and retain that revision's copyright/license notice.

Adopted principles: source-specific endpoint contracts, bounded pagination,
count reconciliation, response-body validation, explicit metadata/full-text
distinction, credential-redacted provenance and source-specific failures.

Integration choices: Python stdlib for Windows portability; one library shared
by MCP and standalone commands; existing exporters and independent-citation
workflows; native query overrides and explicit retrieval bounds. First-batch
scope is described in tools.md; no claim of all 18 upstream APIs being installed.
