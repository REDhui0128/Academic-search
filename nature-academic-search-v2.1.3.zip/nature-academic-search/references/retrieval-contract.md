# Retrieval contract and compatibility

## Search report: schema 2.1

Existing MCP keys total/results/result_count/sources_queried/errors remain.
`total` sums overlapping known database hit counts. Use `unique_count` for
distinct retrieved records.

- `source_counts`: actual/echoed query, reported total and count type,
  received/normalized/retained counts, pages, completion and stop reason.
- `retrieved_count`: raw received records, including overlap.
- `retained_count`: source records retained within the global record budget.
- `unique_count`: deduplicated retained records.
- `complete`: selected queries exhausted without a known gap; not field-wide coverage.
- `requests_used`, `limits`, `provenance`: actual requests, redacted endpoints,
  timestamps and HTTP outcomes. Retries count toward the request budget.
  Semantic Scholar entries include `api_key_sent`; throttled entries may include
  `retry_after_seconds`. Source errors preserve status and remaining cooldown.

Semantic Scholar source counts include `retrieval_method`: `relevance`, `bulk`,
or `bulk_after_429`. The recovery method uses all-term title/abstract matching and
citation/date ordering, with an explicit note; it is not equivalent to relevance
search. A bulk response can contain up to 1,000 rows even in quick recovery.
Quick mode retains at most `limit` records per source; raw received counts remain
visible, omitted rows keep the report partial, and other sources retain their
allocated records.

Stop reasons include exhausted, quick_limit, record_limit, call_limit,
count_mismatch, repeated_page, repeated_cursor, normalization_gap and provider
errors. Estimated totals (Semantic Scholar bulk) do not define exhaustion;
continuation tokens do. Live totals can change. PubMed eSearch has a retrieval
ceiling: larger searches require recorded query partitions and cross-partition dedup.

A bulk API can return more than the requested record budget. Received and retained
counts expose locally omitted records; an omitted tail is never marked complete.

## Records

Keep full authors, DOI/native IDs, title, year, venue and abstract. `ids`, `sources`,
`source_records` and `related_versions` retain provenance. `citation_counts` maps
database to count/date; never add counts. Citation sorting uses one attributed
count per record and reports its source; cross-index values are not equivalent.
Default ranking uses reciprocal source ranks. Date/citation sorting acts only on
the retrieved candidate pool. Comprehensive retrieval applies no hidden relevance
threshold; inclusion screening remains explicit.

## Compatibility

The CLI keeps old flags and list stdout. The Python search() callable stays
OpenAlex-only/list-returning. Use --sources auto or a comma-separated list for
multiple sources. Author-ID filtering is OpenAlex-only and never silently ignored.
--report emits the full report; --report-file saves it while keeping normal stdout.
--limit truncates the displayed list, not the comprehensive report.

Exit 1 means failure with no usable records; partial success may exit 0, so inspect
coverage. full_text.py --download exits 2 if no article file was obtained.
pdf_downloaded does not mean parsed body. Existing reference exporters retain
their entrypoints and file formats.
