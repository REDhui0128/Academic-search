# Source selection and reliability

Use [current routing](../static/core/routing-and-ops.md). Historical T1/T2/T3 labels
mixed access restrictions with reliability; v2.1 selects by domain, metadata
authority and actual availability.

- Crossref supplies registered DOI metadata; publisher records resolve material
  conflicts about publication status and corrections.
- PubMed/Europe PMC specialize in biomedical literature; arXiv in preprints.
  Preprint and published versions retain separate status.
- OpenAlex and Semantic Scholar provide broad discovery/citation metadata.
  Shared upstream records are not independent substantive corroboration.
- Scopus/ScienceDirect have official APIs and account-specific entitlements.
- Google Scholar/WoS/Chinese databases need separately available tools/access.

Attribute citation counts by database/date. Distinguish discovery, bibliographic
identity, full-text evidence and strict independent-citation auditing.
