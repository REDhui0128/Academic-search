# Search strategy

## Query construction

Extract concepts, synonyms, abbreviations and spelling variants relevant to the
question. Engineering examples include wafer warpage/bow, residual stress,
thin-film stress, multilayer deposition and physics-informed neural networks.
Apply user dates/types explicitly; this vocabulary is not mandatory for other topics.

Translate the conceptual query for each source. PubMed uses field tags/MeSH;
arXiv uses all:/ti:/abs:/cat:; Scopus supports TITLE-ABS-KEY. Semantic Scholar bulk
uses +/|/- operators. Crossref/OpenAlex broad text queries need their own syntax.
Pass source_queries instead of distributing one complex native expression to all
APIs. Executed source queries are retained in the report.

## Source selection

Use [routing](../static/core/routing-and-ops.md). Engineering combines broad
indexes, arXiv and explicitly selected Elsevier sources. Biomedical search uses
PubMed/Europe PMC plus broad indexes. Resolve author namesakes before auditing.

## Deduplication and ranking

Use [implemented deduplication](dedup-engine.md). Review ambiguous identities and
preprint/journal links. Deduplicate query-variant reports with the same module,
preserving query provenance. Default cross-source ranking uses reciprocal ranks;
native relevance scores are incomparable. Citation/date sorting acts within the
retrieved pool. Comprehensive mode does not discard low-scored candidates;
inclusion/exclusion remains an explicit screening step.
