# Source contracts

Use these details only for relevant sources. Defaults are conservative pacing,
not guaranteed account quotas; current responses/official documentation govern.

| Source | Search/lookup contract | Important limit |
|---|---|---|
| OpenAlex | /works; search/filter; cursor pagination; meta.count/results | API key via environment; abstracts use inverted indexes |
| Semantic Scholar | /graph/v1/paper/search for quick; /search/bulk for comprehensive or bounded 429 recovery | Bulk total is estimated; follow token; recovery changes matching/ranking and is reported |
| Crossref | /works; query/filter; cursor; message.items | Hit counts overlap other indexes; update-to can identify correction notices |
| arXiv | Atom /api/query; start/max_results | Error entries and plain-text throttling can arrive as HTTP 200 |
| PubMed | ESearch followed by EFetch | ESearch retrieval ceiling; record gaps are reported |
| Europe PMC | /search with cursorMark/resultType=core | Inspect errCode and resultList; IDs include corpus/source |
| Scopus / ScienceDirect | Elsevier search APIs; start/count; selected explicitly | Key/entitlement needed; invalid or capped pagination stays partial |
| Unpaywall | /v2/{DOI}; real email | DOI OA locator; a URL is not verified content |
| CORE | /v3/search/works/ then /v3/works/{id} | Exact DOI check; key needed for fullText; reject unavailable-text sentinel |
| PMC / Europe PMC full text | EFetch db=pmc or /{PMCID}/fullTextXML | Validate identifiers and nonempty JATS body; no retired OA-package endpoint dependency |

Adapters validate response shape. A missing total is unknown, never invented as
zero proof. Source errors preserve earlier pages. Separate expected hit count,
received records, retained records and cross-source unique records.

Shared modules: transport.py for budgets/pacing/retries; records.py for IDs,
deduplication, JATS and inverted abstracts; search.py for adapters/pagination;
fulltext.py for copy discovery/retrieval. Both MCP and CLI call these modules.

Crossref cursor requests preserve their initial page size and other parameters.
Always read the returned next cursor. Legacy servers can repeat an opaque cursor
while rows advance; repeated rows and operation budgets still terminate loops.
arXiv native field queries, including `jr:`, `co:` and `rn:`, are preserved.
Explicit `source_queries` bypass plain-query translation. Plain arXiv terms are
qualified with `all:` while phrases, grouping and AND/OR/ANDNOT are retained;
malformed plain queries are reported before an API request.
The [Crossref cursor migration notes](https://community.crossref.org/t/changes-to-cursors-filtering-and-sorting-in-the-rest-api/16246)
describe the changed behavior. arXiv identifier lookup uses `id_list`, including
an explicitly requested version; ordinary search uses `search_query`.

Official references: https://docs.openalex.org/ ;
https://api.semanticscholar.org/api-docs/ ; https://www.crossref.org/documentation/retrieve-metadata/rest-api/ ;
https://info.arxiv.org/help/api/ ; https://www.ncbi.nlm.nih.gov/books/NBK25501/ ;
https://europepmc.org/RestfulWebService ; https://dev.elsevier.com/ ;
https://unpaywall.org/products/api ; https://core.ac.uk/documentation/api .
