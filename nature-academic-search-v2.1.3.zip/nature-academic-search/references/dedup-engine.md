# Deduplication

Implementation: lib/literature/records.py::deduplicate (shared by MCP and CLI).

1. Normalize DOI prefixes/case and native identifiers; retain arXiv version data.
2. Merge exact identifiers with compatible DOI and version identities.
3. When a DOI is missing, merge only exact normalized title, exact first author
   and year with compatible identities/version types.
4. Keep conflicting identities and preprint/published versions. Preserve possible
   duplicate/version relationships for review.
5. Merge missing metadata and attributed citation counts. Retain native IDs,
   source labels and source records. Never sum citation counts.

Fuzzy matches require review. Conservative rules may leave duplicates. Missing
authors/affiliations remain missing evidence for strict-citation audits.
