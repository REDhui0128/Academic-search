# Workflow 1: Multi-source search

1. Identify topic, dates, scope and quick/comprehensive intent. Resolve author
   ambiguity before treating results as that person's publications.
2. Select sources using [routing](../../static/core/routing-and-ops.md). Build
   appropriate per-source queries and record terminology variants.
3. Use available `search_papers` or `scripts/academic_search.py`. They share the
   engine. Quick mode reads a page per source; comprehensive mode continues within
   explicit global bounds.
4. Inspect errors and source_counts. Retain successful records. Report missing
   sources/pages, normalization gaps and stopped limits. Empty results apply only
   to checked sources and queries.
5. Code handles [deduplication](../dedup-engine.md). Review possible duplicate and
   version relationships. Preserve author lists and attributed citation counts.
6. Present title, authors, year, venue, DOI/ID, source and relevance explanation.
   Summarize scope briefly; save detailed reports for substantial/reproducible searches.
7. Continue [full-text retrieval](wf7-full-text-retrieval.md) or the existing
   export workflow when requested.

Comprehensive API retrieval is one part of a review. Screening, inclusion decisions
and evidence synthesis remain separate work.
