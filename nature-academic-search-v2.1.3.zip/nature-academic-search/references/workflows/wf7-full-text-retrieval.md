# Workflow 7: Open full text

Prefer DOI/PMID/PMCID/arXiv identifiers. For title-only input, search and confirm
title, authors and year first.

1. `find_full_text` / `scripts/full_text.py ID` locates open candidates without
   saving article files. Missing credentials are reported per provider.
2. When download/reading is requested, use `fetch_full_text` with an output folder
   or `scripts/full_text.py ID --download --output-dir PATH`.
3. Inspect `status` and `identity_status`:
   - `oa_link_found`: provider supplies a URL; body not checked.
   - `metadata_only`: no parsed body; constructed XML URLs may be unverified candidates.
   - `pdf_downloaded`: PDF saved; identity or readable text needs review.
   - `full_text_parsed`: JATS/CORE IDs verified or PDF front matter matched. PDF
     matching is heuristic; inspect notes and content before using as evidence.
4. JATS must contain a nonempty body. HTTP 200 alone is insufficient. HTML returned
   from a PDF URL is not a PDF. Access, rate limits or removal can invalidate links.
5. Return saved paths and actual status. Keep the retrieval report beside article
   files. Continue requested reading/translation workflows when needed.

Raw JATS and section text are saved together. Captions and table/equation text are
included where available; the helper does not reproduce layout or replace a
figure-aware bilingual reader. Optional PyMuPDF/pypdf extracts PDF text; scanned
files may need separate OCR.
