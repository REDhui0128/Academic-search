# `nature-academic-search` Skill

[中文说明](README.md)

## Installation and configuration (v2.1.3 package)

Python 3.10+ is required. Place the complete `nature-academic-search` folder under
`~/.codex/skills/`, with `SKILL.md` directly inside the folder, and open a new
Codex conversation to discover it. Registering the optional MCP server is a
separate step.

The bundled `mcp-server/config.toml` contains portable defaults and no publisher
credentials. Copy `.env.example` into your paper project's directory as `.env`,
or merge its fields into an existing `.env`, and supply your own credentials.
Never commit the populated file. Run standalone commands from that project:

```text
python <SKILL_DIR>/scripts/academic_search.py "wafer warpage" --sources openalex,crossref,arxiv --report
python <SKILL_DIR>/scripts/full_text.py PMC7029759 --download --output-dir fulltext
```

Standalone retrieval uses the Python standard library. MCP and some legacy tools
require `mcp-server/requirements.txt`. For MCP, adapt `config/mcp-snippet.json`,
replace `<MCP_SERVER_DIR>` with an absolute path, and set
`NATURE_ACADEMIC_SEARCH_ENV_FILE` to your project's absolute `.env` path if the
launcher changes its working directory. Restart running MCP servers after updates.

Bundled search sources are OpenAlex, Semantic Scholar, Crossref, arXiv, PubMed,
Europe PMC, Scopus and ScienceDirect. Open-copy discovery also uses Unpaywall,
CORE, PMC/Europe PMC, arXiv and OpenAlex locations. Other integrations need
separate tools; this package does not implement all 18 `paper-lookup` sources.
Elsevier access depends on endpoint entitlements, and provider rate limits still
apply. Discovered links, downloaded files and parsed full text have distinct
reported states. See [source contracts](references/source-contracts.md).



## v2.1 first batch

MCP and standalone commands share source adapters, bounded pagination, code
deduplication and source-specific coverage/provenance. OpenAlex, Semantic Scholar
and Europe PMC join the existing search sources. Open-copy discovery and
JATS/PDF retrieval report actual content/identity status. Existing flags, list
stdout and citation exporters remain. See [operations](static/core/routing-and-ops.md).

Example: `python scripts/academic_search.py "wafer warpage" --sources auto --domain engineering --report`.
An already running MCP service must reload its code to expose the new tools.

### v2.1.1 validation fixes

Fixes cover identifier bridging, preprint versions, source ranking, stable
pagination parameters, Crossref authors, PubMed DOI fallback, version-specific
arXiv lookup, and MCP exception handling. See [test instructions](tests/README.md).
PyYAML is a validation dependency; standalone retrieval does not require it.

### v2.1.2 Elsevier configuration compatibility

Dedicated Scopus/ScienceDirect tools and shared search read the same process
environment and project `.env`, retaining legacy pybliometrics configuration.
SDK credentials remain in memory. Default Scopus search can retry STANDARD after
COMPLETE access is rejected and reports the reduced metadata. Set
`NATURE_ACADEMIC_SEARCH_ENV_FILE` when the MCP launcher changes working directory.

### v2.1.3 retrieval recovery and content fixes

Semantic Scholar uses bounded backoff, server cooldowns and a reported bulk
fallback for plain-word quick queries. Provenance records key presence and the
effective retrieval method; fallback changes matching and ranking. Long cooldowns
still stop requests. Fixes also preserve comparison signs in metadata, arXiv
native fields and Boolean queries, and Scopus view-specific first-page limits.

`nature-academic-search` supports multi-source scholarly search, bibliographic metadata checks, citation formatting, strict external-citation audits, and influential-citer analysis.

## What To Use It For

- Search papers across CrossRef, PubMed, arXiv, Scopus, ScienceDirect, and related scholarly sources.
- Retrieve structured paper details by DOI, PMID, or arXiv ID.
- Generate Nature, APA, IEEE, Vancouver, and other citation styles.
- Build MeSH-assisted PubMed search strategies for biomedical topics.
- Audit strict external citations for a target paper while excluding self-citations, team citations, and obvious collaboration-network citations.
- Identify how academy members, Fellows, highly cited scholars, institutional leaders, or field experts cited a target paper.

## Typical Requests

- "Check the strict external citations for this paper and list influential citers."
- "Find 20 recent Nature/Science/Cell-related papers on this topic."
- "Convert these DOIs into Nature-style references and export RIS."
- "Add MeSH terms and synonyms to this PubMed query."

## What You Need To Provide

- Search topic, keywords, time range, journal scope, or target DOI.
- Whether Scopus / ScienceDirect or other locally configured sources may be used.
- The exclusion rule for strict external citations, such as whether to exclude same-institution, coauthor, or lab-network citations.

## Outputs

- Deduplicated paper table with title, authors, year, journal, DOI, and source.
- Formatted citation text or `.ris`, `.bib`, `.nbib`, `.enw` reference-management files.
- Strict external-citation table and citation-context summary.
- Search strategy, source notes, and records that could not be verified.

## Runtime and Dependencies

- PubMed contact/key settings use `PUBMED_EMAIL` / `NCBI_API_KEY` or the existing `mcp-server/config.toml`.
- Scopus / ScienceDirect accept `ELSEVIER_API_KEY` from the environment or project `.env`, with existing `pybliometrics` configuration as a fallback.
- Do not write Elsevier API keys into repository files; keep them in local secure configuration.

## Boundaries

- Secondary scholarly indexes are discovery aids; key fields should be verified through DOI records, PubMed, publisher pages, or authoritative databases.
- Strict external-citation analysis needs a clear exclusion rule; missing author or affiliation metadata is marked as uncertain.
- Restricted databases are not bypassed; the skill reports missing sources or asks for user login when needed.

## Related Skills

- `nature-citation`: match Nature/CNS/Cell supporting citations for manuscript claims.
- `nature-literature-pipeline`: turn one-off search into ongoing literature monitoring.
- `nature-ref-verifier`: verify reference-list metadata field by field.
