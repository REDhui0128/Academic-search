# `nature-academic-search` 技能

[English](README_EN.md)

## 安装与配置（v2.1.3 发布包）

需要 Python 3.10 或更高版本。将完整的 `nature-academic-search` 文件夹放入
`~/.codex/skills/`，使 `~/.codex/skills/nature-academic-search/SKILL.md` 存在。
在 Codex 中重新打开会话以发现技能。技能文件与 MCP 服务注册是两步操作。

发布包内的 `mcp-server/config.toml` 只有通用默认值，不含发布者的配置或凭据。
将根目录 `.env.example` 复制到你的论文项目目录并命名为 `.env`，填写自己的
密钥和邮箱；如果项目已有 `.env`，合并所需字段。不要上传填写后的 `.env`。

在包含 `.env` 的论文项目目录运行（请替换技能文件的路径）：

```powershell
python "<SKILL_DIR>/scripts/academic_search.py" "wafer warpage" --sources openalex,crossref,arxiv --report
python "<SKILL_DIR>/scripts/full_text.py" "PMC7029759" --download --output-dir fulltext
```

独立检索模块使用 Python 标准库；MCP 和部分旧工具的依赖见
`mcp-server/requirements.txt`。需要 MCP 时安装这些依赖，并参照
`config/mcp-snippet.json` 配置客户端，将 `<MCP_SERVER_DIR>` 替换为
技能内 `mcp-server` 文件夹的绝对路径。若启动器改变工作目录，在 MCP
进程环境中设置 `NATURE_ACADEMIC_SEARCH_ENV_FILE` 为项目 `.env` 的绝对路径。
运行中的 MCP 服务需要重启以加载代码和配置。

### 来源与访问条件

内置检索来源：OpenAlex、Semantic Scholar、Crossref、arXiv、PubMed、Europe PMC、
Scopus、ScienceDirect。开放全文渠道包含 Unpaywall、CORE、PMC／Europe PMC、
arXiv 及 OpenAlex 提供的开放版本地址。Google Scholar、Web of Science 和中文
数据库需要另接工具；本包未接入 `paper-lookup` 的全部 18 个来源。

API key 不保证付费全文或机构接口权限。Elsevier 详细视图及 ScienceDirect
需要对应接口授权；Semantic Scholar 等来源仍可能限流。全文定位、下载成功和
正文解析分别记录，不能互相替代。详见 [来源说明](references/source-contracts.md)。



## v2.1 第一批升级

- MCP 和独立命令共用检索模块：新增 OpenAlex、Semantic Scholar、Europe PMC，接续原有来源。
- 快速／全面检索、分页、代码去重、分来源数量核对和检索记录。
- 新增开放全文定位、JATS／PDF 获取与正文状态识别；部分来源需要配置邮箱或 API key。
- 旧参数、列表输出和引用导出继续兼容。详见 [运行说明](static/core/routing-and-ops.md)。

独立命令示例：`python scripts/academic_search.py "wafer warpage" --sources auto --domain engineering --report`。
已运行的 MCP 服务需要重新加载代码后才能出现新增工具。

### v2.1.1 验证与修复

修复跨编号去重、预印本版本保留、来源排序分数、分页参数稳定性、
Crossref 作者字段、PubMed DOI 回退、arXiv 指定版本查询，以及 MCP 异常处理。
离线测试覆盖这些路径和全文状态判断；运行方式见 [测试说明](tests/README.md)。
测试依赖包含 PyYAML；运行检索脚本本身不需要 PyYAML。

### v2.1.2 Elsevier 配置兼容

旧 Scopus／ScienceDirect 专用工具和统一检索共用环境变量、项目 `.env`，
兼容既有 `pybliometrics` 配置，密钥仅在内存中传入 SDK。
Scopus 默认详细视图权限不足时，可重试基础视图，并明确报告字段减少。
MCP 切换启动目录时，使用 `NATURE_ACADEMIC_SEARCH_ENV_FILE` 指定项目 `.env`。

### v2.1.3 检索恢复与内容修复

Semantic Scholar 支持有上限的退避重试、服务端等待时间和普通词查询的 bulk 备用检索，
并记录密钥是否发送、实际检索方式及排序变化。长时间限流仍按服务端要求停止请求。
修复摘要不等式误删、arXiv 原生字段与布尔检索式改写问题，以及 Scopus 详细视图的
单页条数上限。备用检索和正常检索共用请求预算；配置文件和密钥继续沿用。

`nature-academic-search` 用于多源学术检索、文献元数据核查、引用格式生成、严格他引审计和高影响力引用者分析。

## 适合用它做什么

- 在 CrossRef、PubMed、arXiv、Scopus、ScienceDirect 等来源中检索论文。
- 根据 DOI、PMID 或 arXiv ID 获取结构化文献信息。
- 生成 Nature、APA、IEEE、Vancouver 等引用格式。
- 构建 MeSH 检索式，辅助医学和生命科学主题检索。
- 审计目标论文的严格他引，排除自引、团队引和明显合作网络引用。
- 识别院士、Fellow、高被引学者、院校领导或领域专家如何引用目标论文。

## 典型请求

- “帮我查这篇论文的严格他引，并列出高影响力引用者。”
- “按这个主题找 20 篇近五年的 Nature/Science/Cell 相关论文。”
- “把这些 DOI 转成 Nature 格式引用，并导出 RIS。”
- “为 PubMed 检索式补 MeSH 词和同义词。”

## 你需要提供

- 检索主题、关键词、时间范围、期刊范围或目标文献 DOI。
- 是否允许使用 Scopus / ScienceDirect 等需要本机配置的来源。
- 严格他引的排除口径，例如是否排除同机构、共同作者或课题组网络。

## 产出

- 去重后的文献表，包含标题、作者、年份、期刊、DOI 和来源。
- 引用格式文本或 `.ris`、`.bib`、`.nbib`、`.enw` 等文献管理文件。
- 严格他引统计表和引用上下文摘要。
- 查询策略、数据源说明和无法验证的条目列表。

## 运行和依赖

- PubMed 可通过 `PUBMED_EMAIL` / `NCBI_API_KEY` 或原有 `mcp-server/config.toml` 配置联系信息和密钥。
- Scopus / ScienceDirect 接受环境变量或项目 `.env` 中的 `ELSEVIER_API_KEY`，也兼容既有 `pybliometrics` 配置。
- 不要把 Elsevier API key 写入仓库文件；只在本机安全配置中保存。

## 边界

- 二级学术索引只能作为发现线索，关键字段应回到 DOI、PubMed、出版社页面或数据库记录核实。
- 严格他引判断需要明确排除规则；没有作者/机构信息时会标注不确定。
- 无权限数据库不会被绕过，只会报告缺失来源或需要用户登录。

## 相关技能

- `nature-citation`：为手稿 claim 匹配 Nature/CNS/Cell 支撑文献。
- `nature-literature-pipeline`：把一次性检索升级为持续文献监测。
- `nature-ref-verifier`：逐条核查参考文献字段。
