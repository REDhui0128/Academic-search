"""Keep offline tests independent of the user's credentials and working folder."""
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parent
for directory in ("lib", "scripts", "mcp-server"):
    sys.path.insert(0, str(ROOT / directory))

from literature import configuration
from literature import transport
from literature.configuration import ENV_NAMES


@pytest.fixture(autouse=True)
def isolate_offline_credentials(request, monkeypatch, tmp_path):
    if request.path.name == "test_elsevier_live.py":
        return
    for name in ENV_NAMES | {"NATURE_ACADEMIC_SEARCH_ENV_FILE"}:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setattr(transport, "_next_request", {})
    monkeypatch.setattr(transport, "_cooldown_until", {})
    monkeypatch.setattr(transport, "_cooldown_status", {})
    monkeypatch.setattr(configuration, "_configuration_path", lambda: None)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("NATURE_ACADEMIC_SEARCH_CACHE_DIR", str(tmp_path / "sdk-cache"))
