#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# ///
"""Standalone search using the same retrieval engine as the MCP tools.

Existing author/affiliation/ORCID/limit/sort/mailto/compact arguments remain
supported. Default stdout remains a JSON list; --report emits the full coverage
report. --report-file writes that report without changing legacy stdout.
Multi-source, comprehensive and source-native query options are additive.
"""

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from literature.search import search as shared_search
from literature.transport import Client, RetrievalError, openalex_params
from literature.configuration import environment_value
import urllib.request
import urllib.parse
import urllib.error


OPENALEX_API = "https://api.openalex.org/works"
AUTHORS_API = "https://api.openalex.org/authors"
# Polite-pool contact; overridden by --mailto or OPENALEX_MAILTO / CROSSREF_MAILTO.
MAILTO = ""

# When re-ranking a query's results by citations/date, drop candidates whose
# relevance_score is below this fraction of the top hit's score. OpenAlex's
# relevance_score carries a citation boost, so a handful of weakly-matching but
# ultra-cited papers (e.g. a 3000-cite medical paper for a civil-engineering query)
# sneak into the pool; without this floor, re-ranking by citations floats them to
# the top. Empirically off-topic papers score ~0.2x the top hit while on-topic ones
# stay above ~0.3x, so 0.3 cleanly separates them.
RELEVANCE_FLOOR = 0.3


def _institution(author: dict) -> str:
    insts = author.get("last_known_institutions") or []
    if isinstance(insts, list) and insts:
        return insts[0].get("display_name", "") or ""
    # Fall back to the most recent listed affiliation if no last-known institution.
    for aff in (author.get("affiliations") or []):
        n = (aff.get("institution") or {}).get("display_name")
        if n:
            return n
    return ""


def _aff_match(author: dict, affiliation: str) -> bool:
    """True if `affiliation` matches the author's PRIMARY (last-known) institution.

    Matching only the last-known institution-rather than every historical
    affiliation-keeps a high-volume namesake with a tenuous past link to the
    target institution from hijacking the result (e.g. a 273-paper radar
    "Shenghua Zhou" who once brushed against "Hong Kong" must not outrank the
    real civil-engineering one whose last-known institution *is* Hong Kong).
    """
    aff = affiliation.lower()
    names = [inst.get("display_name", "") for inst in (author.get("last_known_institutions") or [])]
    if not names:
        names = [_institution(author)]  # fall back to most recent listed affiliation
    return any(aff in (n or "").lower() for n in names)


def _cluster_summary(results: list[dict]) -> list[dict]:
    """Collapse author records into (name, institution) clusters, most-prolific first.

    Lets callers see the *distinct* people behind a colliding name (e.g. a
    medical and a civil-engineering "Shenghua Zhou") instead of silently
    inheriting whichever cluster happens to be largest.
    """
    clusters: dict[tuple, dict] = {}
    for a in results:
        key = ((a.get("display_name") or "").lower(), _institution(a))
        c = clusters.setdefault(key, {
            "name": a.get("display_name", ""),
            "institution": _institution(a),
            "works_count": 0,
            "ids": [],
        })
        c["works_count"] += a.get("works_count") or 0
        c["ids"].append((a.get("id") or "").rsplit("/", 1)[-1])
    return sorted(clusters.values(), key=lambda c: -c["works_count"])


def fetch_author_candidates(name: str, per_page: int = 50) -> list[dict]:
    params = {"search": name, "per_page": per_page, "mailto": MAILTO}
    data = Client(max_calls=2).json(AUTHORS_API, openalex_params(params))
    return data.get("results", [])


def resolve_author(name: str, affiliation: str | None = None) -> dict | None:
    """Resolve an author name to OpenAlex author ID(s).

    OpenAlex often splits one real person into several records, and common
    (e.g. romanised Chinese) names collide across unrelated people. We therefore:
      1. optionally keep only candidates whose affiliation matches `affiliation`
         (case-insensitive substring over the last-known institution); then
      2. pick the most prolific institution-bearing candidate as the anchor; then
      3. merge namesakes that share the anchor's name and institution.
    The returned dict always carries a `candidates` cluster summary so callers
    can detect/repair a wrong pick. When `affiliation` matches nothing, returns
    a dict with empty `ids` and `no_affiliation_match` set (not None).
    """
    results = fetch_author_candidates(name)
    if not results:
        return None

    clusters = _cluster_summary(results)
    pool = results
    if affiliation:
        pool = [a for a in results if _aff_match(a, affiliation)]
        if not pool:
            return {"ids": [], "display_name": name, "institution": "",
                    "works_count": 0, "candidates": clusters,
                    "no_affiliation_match": affiliation}

    # Prefer candidates that have a known institution, then the most prolific.
    pool = sorted(pool, key=lambda a: (_institution(a) == "", -(a.get("works_count") or 0)))
    best = pool[0]
    best_name = (best.get("display_name") or "").lower()
    best_inst = _institution(best)

    ids, works = [], 0
    for a in results:
        if (a.get("display_name") or "").lower() != best_name:
            continue
        # Only merge namesakes that share the institution; if the anchor has
        # no institution we can't disambiguate, so keep that single record.
        if best_inst:
            if _institution(a) != best_inst:
                continue
        elif a is not best:
            continue
        ids.append((a.get("id") or "").rsplit("/", 1)[-1])
        works += a.get("works_count") or 0

    return {
        "ids": ids,
        "display_name": best.get("display_name", ""),
        "institution": best_inst,
        "works_count": works,
        "candidates": clusters,
    }


def resolve_by_orcid(orcid: str) -> dict | None:
    """Resolve an ORCID (bare 0000-... or full URL) to its OpenAlex author ID(s)."""
    oid = orcid.strip().rsplit("/", 1)[-1]
    # 0000-0000-0000-0000 is a checksum-valid but unassigned placeholder some
    # records carry; reject it so it can't resolve to whoever holds that junk tag.
    if set(oid) <= {"0", "-"}:
        return None
    params = {"filter": f"orcid:{oid}", "mailto": MAILTO}
    data = Client(max_calls=2).json(AUTHORS_API, openalex_params(params))
    results = data.get("results", [])
    # Defensive: only keep records that actually carry the requested ORCID, so a
    # server-side filter miss can't resolve to an unrelated author. OpenAlex
    # stores orcid as a full URL, e.g. https://orcid.org/0000-....
    results = [a for a in results if (a.get("orcid") or "").rstrip("/").endswith(oid)]
    if not results:
        return None
    best = results[0]
    return {
        "ids": [(a.get("id") or "").rsplit("/", 1)[-1] for a in results],
        "display_name": best.get("display_name", ""),
        "institution": _institution(best),
        "works_count": sum(a.get("works_count") or 0 for a in results),
        "candidates": _cluster_summary(results),
    }


def search(query: str | None = None, limit: int = 10, year_from: int | None = None,
           sort: str = "relevance_score", author_id: str | None = None) -> list[dict]:
    # Keep the callable's OpenAlex-only list contract for existing consumers.
    report = shared_search(query, sources=["openalex"], limit=limit,
                           year_from=year_from, sort=sort, author_id=author_id)
    if report["errors"] and not report["results"]:
        raise RetrievalError(report["errors"][0]["message"])
    return report["results"][:limit]


def main():
    parser = argparse.ArgumentParser(description="Multi-source literature search with coverage reports")
    parser.add_argument("query", nargs="?", default=None,
                        help="Search query (optional when --author/--author-id/--orcid is given)")
    parser.add_argument("--author", default=None,
                        help="Filter by author name (resolved to OpenAlex author IDs)")
    parser.add_argument("--affiliation", default=None,
                        help="Constrain --author to an institution (case-insensitive substring); "
                             "disambiguates colliding names")
    parser.add_argument("--orcid", default=None,
                        help="Resolve author by ORCID (unambiguous); takes precedence over --author")
    parser.add_argument("--list-authors", action="store_true",
                        help="List same-name author clusters for --author and exit (for disambiguation)")
    parser.add_argument("--author-id", default=None,
                        help="Filter by exact OpenAlex author ID(s), e.g. A5055881494 (OR-join with '|')")
    parser.add_argument("--limit", type=int, default=10, help="Maximum displayed records; comprehensive report retains the retrieved set")
    parser.add_argument("--year-from", type=int, default=None, help="Filter papers from this year")
    parser.add_argument("--sort", default="relevance_score",
                        choices=["relevance_score", "cited_by_count", "publication_date"],
                        help="Sort order. With a query, cited_by_count/publication_date "
                             "re-rank within the relevance-matched pool (not the whole DB)")
    parser.add_argument("--mailto", default=None,
                        help="Contact email for the OpenAlex polite pool "
                             "(falls back to OPENALEX_MAILTO / CROSSREF_MAILTO env)")
    parser.add_argument("--compact", action="store_true", help="Compact output (one line per paper)")
    parser.add_argument("--sources", help="Comma-separated sources; default OpenAlex for compatibility; 'auto' uses --domain")
    parser.add_argument("--domain", choices=["general", "engineering", "biomedical", "preprints"], default="general")
    parser.add_argument("--mode", choices=["quick", "comprehensive"], default="quick")
    parser.add_argument("--max-records", type=int, default=1000)
    parser.add_argument("--max-calls", type=int, default=50)
    parser.add_argument("--source-query", action="append", default=[], metavar="SOURCE=QUERY")
    parser.add_argument("--report", action="store_true", help="Emit the complete JSON report instead of a list")
    parser.add_argument("--report-file", help="Save complete coverage/provenance JSON")
    args = parser.parse_args()
    if args.report and args.compact:
        parser.error("--report and --compact are mutually exclusive")

    # Resolve the polite-pool contact: --mailto > OPENALEX_MAILTO > CROSSREF_MAILTO > default.
    global MAILTO
    MAILTO = (args.mailto or environment_value("OPENALEX_MAILTO")
              or environment_value("CROSSREF_MAILTO") or MAILTO)
    if MAILTO:
        os.environ["OPENALEX_MAILTO"] = MAILTO

    if (not args.query and not args.author and not args.author_id
            and not args.orcid and not args.list_authors):
        parser.error("provide a search query, or use --author / --author-id / --orcid")

    def _fmt_cluster(c: dict) -> str:
        return f"  {(c['institution'] or 'unknown institution'):<42} | {c['works_count']:>5} works | {'|'.join(c['ids'])}"

    # --list-authors: dump the distinct same-name clusters and exit.
    if args.list_authors:
        if not args.author:
            parser.error("--list-authors requires --author")
        try:
            cands = _cluster_summary(fetch_author_candidates(args.author))
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError, RetrievalError) as e:
            print(f"ERROR: author lookup failed: {e}", file=sys.stderr)
            return 1
        if not cands:
            print(f"ERROR: no author found in OpenAlex: {args.author}", file=sys.stderr)
            return 1
        print(f"Same-name author clusters for \"{args.author}\" (by works count, desc):", file=sys.stderr)
        for c in cands[:15]:
            print(_fmt_cluster(c))
        print("-> use --affiliation \"keyword\" or --author-id <ID> to pin the right person", file=sys.stderr)
        return 0

    author_id = args.author_id
    matched = None
    if not author_id and (args.orcid or args.author):
        try:
            matched = (resolve_by_orcid(args.orcid) if args.orcid
                       else resolve_author(args.author, args.affiliation))
        except urllib.error.HTTPError as e:
            print(f"ERROR: author lookup returned HTTP {e.code}: {e.reason}", file=sys.stderr)
            return 1
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError, RetrievalError) as e:
            print(f"ERROR: author lookup failed: {e}", file=sys.stderr)
            return 1
        if not matched or not matched.get("ids"):
            if matched and matched.get("no_affiliation_match"):
                print(f"ERROR: author \"{args.author}\" has no record at institution "
                      f"\"{matched['no_affiliation_match']}\". Options (by works count):", file=sys.stderr)
                for c in (matched.get("candidates") or [])[:10]:
                    print(_fmt_cluster(c), file=sys.stderr)
            elif args.orcid:
                print(f"ERROR: no author found in OpenAlex for ORCID: {args.orcid}", file=sys.stderr)
            else:
                print(f"ERROR: no author found in OpenAlex: {args.author}", file=sys.stderr)
            return 1
        author_id = "|".join(matched["ids"])
        inst = matched["institution"] or "unknown institution"
        print(f"Matched author: {matched['display_name']} | {inst} | "
              f"merged {len(matched['ids'])} author record(s), ~{matched['works_count']} works | "
              f"{author_id}", file=sys.stderr)
        # Warn on silent collisions: same name, other institutions present, and the
        # caller didn't pin it down with --affiliation/--orcid.
        if args.author and not args.affiliation and not args.orcid:
            others = [c for c in (matched.get("candidates") or [])
                      if c["institution"] and c["institution"] != matched["institution"]]
            if others:
                tops = "; ".join(f"{c['institution']} ({c['works_count']} works)" for c in others[:3])
                print(f"WARNING: same-name authors at other institutions exist; "
                      f"if this is the wrong one add --affiliation or --orcid: {tops}",
                      file=sys.stderr)

    try:
        source_queries = {}
        for entry in args.source_query:
            source, separator, query_value = entry.partition("=")
            if not separator or not source or not query_value:
                parser.error("--source-query requires SOURCE=QUERY")
            source_queries[source] = query_value
        sources = None if args.sources == "auto" else (args.sources.split(",") if args.sources else ["openalex"])
        report = shared_search(args.query, sources=sources, limit=args.limit,
                               year_from=args.year_from, sort=args.sort, author_id=author_id,
                               mode=args.mode, domain=args.domain, max_records=args.max_records,
                               max_calls=args.max_calls, source_queries=source_queries)
    except (ValueError, RetrievalError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    if matched:
        report["author_resolution"] = matched
    results = report["results"][:args.limit]
    report["displayed_count"] = len(results)
    if args.report_file:
        destination = Path(args.report_file).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    incomplete = [f"{source}:{info['stop_reason']}" for source, info in report["source_counts"].items() if not info["complete"]]
    if incomplete:
        print("COVERAGE: " + "; ".join(incomplete), file=sys.stderr)
    if args.report:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1 if report["errors"] and not report["results"] else 0

    if args.compact:
        for r in results:
            authors_str = ", ".join(r["authors"][:3])
            if len(r["authors"]) > 3:
                authors_str += " et al."
            print(f"[{r['year']}] {r['title']} | {authors_str} | {r['journal']} | DOI:{r['doi']} | Cited:{r.get('cited_by_count', 'NA')}")
    else:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    return 1 if report["errors"] and not results else 0


if __name__ == "__main__":
    sys.exit(main())
