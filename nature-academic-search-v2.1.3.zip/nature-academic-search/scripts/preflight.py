#!/usr/bin/env python3
"""Inspect selected source configuration and optionally probe API responses."""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from literature.search import SOURCES, _elsevier_headers, fetch_page
from literature.configuration import environment_value
from literature.transport import Client, RetrievalError, setting


def check_endpoints(sources=None, probe=True):
    results = {}
    for source in sources or ["pubmed", "crossref", "arxiv"]:
        start = time.perf_counter()
        info = {"ok": None, "configuration": "public", "probe": "not_run", "error": None}
        try:
            if source in {"scopus", "sciencedirect"}:
                _elsevier_headers()
                info["configuration"] = "key_present_entitlement_unverified"
            elif source == "unpaywall":
                info["configuration"] = "email_present" if environment_value("UNPAYWALL_EMAIL") else "missing_email"
            elif source == "core":
                info["configuration"] = "key_present_full_text_unverified" if environment_value("CORE_API_KEY") else "metadata_only_without_key"
            elif source == "semantic_scholar":
                info["configuration"] = "key_present" if environment_value("S2_API_KEY", aliases=("SEMANTIC_SCHOLAR_API_KEY",)) else "shared_public_pool"
            elif source == "openalex":
                info["configuration"] = "key_present" if environment_value("OPENALEX_API_KEY") else "public_access_unverified"
            elif source == "pubmed":
                info["configuration"] = "key_present" if setting("NCBI_API_KEY") else "public"
            elif source not in SOURCES and source != "pmc":
                raise ValueError("Unknown source: " + source)
            if probe and source in SOURCES:
                client = Client(max_calls=3, timeout=15)
                page = fetch_page(source, "wafer", None, 1, client, {"mode": "quick"})
                info.update(ok=True, probe="structured_response", returned=len(page.records), provenance=client.provenance)
            else:
                info["note"] = "Configuration does not prove connectivity or per-article full-text access"
        except Exception as exc:
            info.update(ok=False, probe="failed" if probe else "not_run",
                        error=str(exc) if isinstance(exc, (ValueError, RetrievalError)) else type(exc).__name__)
        info["time"] = round(time.perf_counter() - start, 3)
        results[source] = info
    return results


def print_report(results):
    for source, info in results.items():
        print(f"{source}: configuration={info['configuration']}; probe={info['probe']}"
              + (f"; {info['error']}" if info["error"] else ""))
    return all(info["ok"] is not False for info in results.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources", default="pubmed,crossref,arxiv")
    parser.add_argument("--config-only", action="store_true", help="Inspect configuration without network requests")
    args = parser.parse_args()
    results = check_endpoints([s.strip() for s in args.sources.split(",") if s.strip()], not args.config_only)
    return 0 if print_report(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
