#!/usr/bin/env python3
"""Locate or retrieve open article content without requiring an MCP server."""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
from literature.fulltext import discover, retrieve
from literature.transport import Client, RetrievalError


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("identifier", help="DOI, PMID, PMCID, arXiv, OpenAlex or Semantic Scholar ID")
    parser.add_argument("--id-type", default="auto", choices=["auto", "doi", "pmid", "pmcid", "arxiv", "openalex", "s2"])
    parser.add_argument("--download", action="store_true", help="Retrieve article files into --output-dir")
    parser.add_argument("--output-dir", help="Required with --download")
    parser.add_argument("--max-calls", type=int, default=30)
    args = parser.parse_args()
    if args.download and not args.output_dir:
        parser.error("--download requires --output-dir")
    try:
        result = (retrieve(args.identifier, args.output_dir, args.id_type, args.max_calls)
                  if args.download else discover(args.identifier, args.id_type, Client(args.max_calls)))
    except (ValueError, OSError, RetrievalError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.download and result["status"] not in {"full_text_parsed", "pdf_downloaded"}:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
