# Tools and shared modules

## Bundled MCP tools

| Tool | Role |
|---|---|
| `search_papers` | Eight-source search, quick/comprehensive modes, code deduplication and coverage reports |
| `get_paper_by_id` | Existing DOI/PMID/arXiv details; PMCID/OpenAlex/Semantic Scholar additions |
| `get_citation`, `lookup_mesh` | Existing formatted citation and MeSH functionality |
| `find_full_text` | Open-copy discovery; no article files saved |
| `fetch_full_text` | Requested download, parsing, identity status and saved paths |
| `search_scopus`, `get_scopus_abstract`, `get_scopus_citation_overview` | Existing Scopus operations |
| `search_scopus_authors`, `get_scopus_author` | Author records |
| `search_scopus_affiliations`, `get_scopus_affiliation` | Affiliation records |
| `search_scopus_serial_titles`, `get_scopus_serial_title`, `get_scopus_plumx_metrics` | Serials and metrics |
| `search_sciencedirect`, `get_sciencedirect_article_metadata` | Existing ScienceDirect operations |

Dedicated legacy source tools retain their original result shapes and first-page
behavior. Use `search_papers` for pagination and cross-source deduplication.
Discover connected tools before calling them.

## Standalone entrypoints

- `scripts/academic_search.py`: same engine as MCP. Default stdout stays a JSON
  list; `--report` emits coverage/provenance; `--report-file` saves it separately.
- `scripts/full_text.py`: lookup; `--download --output-dir PATH` saves article files.
- `scripts/format-converter.py`: existing DOI/PMID/arXiv RIS/BIB/ENW/NBIB exports.
- `scripts/preflight.py`: selected-source configuration and response probes.

Shared networking and JATS parsing use Python 3.10+ standard library. Existing
MCP dependencies remain requests/toml/lxml/pybliometrics. Optional PyMuPDF or
pypdf provides PDF extraction; do not install one merely to locate a link.

## External integrations

Google Scholar, WoS, paper-search MCP and extra PubMed utilities are optional
external integrations. Use only when actually connected. This batch does not
implement direct OpenCitations, bioRxiv/medRxiv, Zenodo, Figshare, ROR, DOAJ,
BioStudies or PubTator3 adapters.

Shared guidance: [deduplication](../../references/dedup-engine.md),
[query strategy](../../references/search-strategy.md),
[citation parser](../../references/citation-parser.md),
[formats](../../references/ris-bibtex-format.md),
[retrieval contract](../../references/retrieval-contract.md).
