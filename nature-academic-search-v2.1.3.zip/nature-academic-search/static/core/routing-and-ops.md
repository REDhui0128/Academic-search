# Source routing and operations

Select by domain, metadata authority and actual availability. Access restrictions
are separate from reliability; Scopus is an official API source. Use current
response headers/contracts for quotas rather than old fixed rate claims.

| Need | Sources |
|---|---|
| General | OpenAlex, Semantic Scholar, Crossref |
| Engineering / PINN / wafer warpage | OpenAlex, Semantic Scholar, arXiv; Crossref; explicitly selected Scopus/ScienceDirect when authorized |
| Biomedical | PubMed, Europe PMC, OpenAlex |
| Physics/CS/math preprints | arXiv, Semantic Scholar, OpenAlex |
| DOI verification | Crossref and complementary identifier lookups |
| Open copies | Unpaywall, CORE, OpenAlex locations, arXiv; PMC/Europe PMC where indexed |
| Chinese databases | Separately available tools/access; no bundled CNKI/万方 connector |

`search_papers` preserves its old Crossref/PubMed/arXiv defaults. Pass
`sources=["auto"]`, `domain="engineering"`, or explicit sources for new routing.
CLI default remains OpenAlex; use `--sources auto --domain engineering`.
Automatic routing does not enable Elsevier sources without explicit selection.

## Modes

- `quick`: one relevance-oriented page per source for a short reading list.
- `comprehensive`: continue pages within a global retained-record and HTTP-call
  budget. Defaults: 1,000 retained source records, 50 HTTP requests. Bounds are
  configurable; successful results survive another source's failure.
- Each host is paced. HTTP 429/503 gets one retry, or up to two retries for
  Semantic Scholar. Respect Retry-After; absent that header, Semantic Scholar
  waits 5 then 10 seconds. Host cooldowns apply across clients in the same process.
  A remaining wait over 30 seconds is reported without another request. Attempts
  count toward max_calls; separate processes do not share these local timers.
- After persistent Semantic Scholar quick-search 429 responses, a first-page
  query containing only plain words may use the official bulk endpoint, with
  the same key and cooldown. Bulk requires all terms in titles/abstracts and uses
  citation-count order (or publication date for date sorting). This changes
  matching and ranking: inspect `retrieval_method`, `notes`, and received versus
  retained counts. Long cooldowns, authentication failures, advanced query syntax,
  and exhausted budgets do not trigger this recovery path.
- Pass source-native queries through `source_queries` or repeated
  `--source-query SOURCE=QUERY`. Query expansion is an explicit agent step.

## Configuration

| Provider | Environment/configuration |
|---|---|
| OpenAlex | `OPENALEX_API_KEY`; optional `OPENALEX_MAILTO` |
| Semantic Scholar | `S2_API_KEY` or existing `SEMANTIC_SCHOLAR_API_KEY` |
| NCBI | `NCBI_API_KEY`; optional `PUBMED_EMAIL` |
| Crossref | optional `CROSSREF_MAILTO` |
| Unpaywall | real contact email `UNPAYWALL_EMAIL` |
| CORE | `CORE_API_KEY` enables this client's full-text requests; metadata may work without it |
| Elsevier | `ELSEVIER_API_KEY`; optional `ELSEVIER_INSTTOKEN`; existing pybliometrics configuration remains a fallback |

The shared engine and dedicated Elsevier tools use the same configuration reader.
Priority is: nonempty process environment, allowed values in the project's `.env`,
then existing provider configuration. For `.env`, read only the working directory's
file, or set `NATURE_ACADEMIC_SEARCH_ENV_FILE` to an explicit absolute path.
Parent folders are not searched. Files are UTF-8 (BOM allowed); quoted values,
`export NAME=value` and comments are supported. Variable expansion and shell
commands are not executed. Unrelated environment settings are ignored.

The SDK bridge passes Elsevier keys/tokens in memory; its temporary configuration
contains only cache paths and request settings and is removed after initialization.
It retains legacy request/proxy/cache settings without rewriting the original file.
`PYBLIOMETRICS_CONFIG_FILE` selects an existing legacy file when needed.
`NATURE_ACADEMIC_SEARCH_CACHE_DIR` optionally relocates SDK response caches.
Changing keys triggers SDK reinitialization; an overridden key never inherits a
legacy key's institutional token. Separate multiple keys/tokens with commas in
corresponding order when using the SDK; shared search uses the first pair.

Dedicated Scopus search keeps its default COMPLETE view, but on 401/403 retries
once with STANDARD when no explicit `view` was supplied. Results report
`requested_view`, `effective_view` and `notes` after fallback. STANDARD results may
omit abstracts and detailed authors. An explicit COMPLETE request, abstract
retrieval, ScienceDirect access, and other specialized endpoints do not silently
downgrade. A working basic search does not establish access to these endpoints.
Dedicated Scopus search retains first-page behavior. COMPLETE/COMPONENT requests
are capped at 25 rows and report `requested_rows`/`effective_rows` when capped;
STANDARD retains the existing 50-row client maximum.

Missing credentials affect that source. Presence does not prove connectivity or
institutional entitlement. Read only needed environment values; never echo keys
or copy them into skill files. Request provenance redacts credential/contact fields.
Existing MCP TOML PubMed key/email and Crossref mailto fields remain fallbacks
when corresponding environment and `.env` values are unset.
Semantic Scholar provenance records `api_key_sent` as a Boolean, never the key.
Presence in a request does not by itself prove that the service accepted it.

## Standalone examples

Resolve script paths against this skill directory and run from the project that
contains `.env`, or set `NATURE_ACADEMIC_SEARCH_ENV_FILE` explicitly:

```powershell
python scripts/academic_search.py "physics informed neural networks wafer warpage" --sources auto --domain engineering --report
python scripts/academic_search.py "wafer warpage" --sources openalex,crossref,arxiv --mode comprehensive --report-file retrieval.json
python scripts/full_text.py "10.1038/nature14539"
python scripts/full_text.py "PMC7029759" --download --output-dir fulltext
python scripts/preflight.py --sources openalex,semantic_scholar,unpaywall,core --config-only
```

`--report-file` saves all retained deduplicated records; `--limit` controls the
displayed list. Use the report as a comprehensive search's working set. Existing
author/affiliation/ORCID flags remain; author matching is OpenAlex-only.

## Existing MCP runtime

```text
uv run --no-project --directory <mcp-server> --with "mcp>=1.0.0,<2.0.0" --with "requests>=2.28.0,<3.0.0" --with "toml>=0.10.2,<2.0.0" --with "lxml>=4.9.0,<6.0.0" --with "pybliometrics>=4.4.1,<5.0.0" python academic_search_server.py
```

A running MCP process must reload to use changed code. Standalone commands read
the installed files on each invocation. Installation alone does not verify live
API access. See [source contracts](../../references/source-contracts.md).

`uv --directory` changes the working directory to the server folder. Configure
`NATURE_ACADEMIC_SEARCH_ENV_FILE` in that MCP process's environment, for example
`D:\your-project\.env`; do not copy API keys into the skill or launcher. Without an
explicit path, `.env` is resolved relative to the server process's working folder.
