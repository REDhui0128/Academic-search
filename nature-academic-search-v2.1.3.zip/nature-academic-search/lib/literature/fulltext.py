"""Resolve open copies and retrieve verified JATS or available PDF content."""

from __future__ import annotations

import hashlib
import io
import json
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import quote, urljoin

from .records import doi, identifier, parse_jats, text
from .configuration import environment_value
from .search import (EUROPEPMC, NCBI, OPENALEX, SEMANTIC, S2_FIELDS, ncbi_params,
                     fetch_page, normalize_crossref, normalize_europepmc, normalize_openalex, normalize_semantic)
from .transport import Client, RetrievalError, openalex_params, safe_url, semantic_headers, setting, utc_now


def _error(source, exc):
    return {"source": source, "kind": exc.kind if isinstance(exc, RetrievalError) else "invalid_response",
            "message": str(exc) if isinstance(exc, RetrievalError) else "Unexpected metadata response"}


def _matches(paper, expected):
    ids = paper.get("ids") or {}
    matched = False
    for key, value in expected.items():
        observed = ids.get(key) or paper.get(key)
        if observed:
            if key == "arxiv_id":
                expected_version = re.search(r"v(\d+)$", value)
                if expected_version:
                    observed_version = paper.get("arxiv_version")
                    if observed_version != expected_version.group(1):
                        return False
                observed, value = re.sub(r"v\d+$", "", observed), re.sub(r"v\d+$", "", value)
            if observed != value:
                return False
            matched = True
    return matched


def _query_string(value):
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def lookup(identifier_value, id_type="auto", client=None):
    client = client or Client(max_calls=12)
    kind, value = identifier(identifier_value, id_type)
    mapped = {"arxiv": "arxiv_id", "openalex": "openalex_id", "s2": "semantic_scholar_id"}.get(kind, kind)
    expected = {mapped: value}
    errors = []
    if kind == "arxiv":
        try:
            page = fetch_page("arxiv", "", None, 1, client, {"arxiv_ids": value})
            for paper in page.records:
                if _matches(paper, expected):
                    return paper, errors
            raise RetrievalError("Identifier not found in arXiv", "not_found")
        except Exception as exc:
            errors.append(_error("arxiv", exc))
    if kind == "doi":
        try:
            response = client.json("https://api.crossref.org/works/" + quote(value, safe=""),
                                   {"mailto": setting("CROSSREF_MAILTO")})
            paper = normalize_crossref(response["message"])
            if _matches(paper, expected):
                return paper, errors
            raise RetrievalError("Crossref identifier mismatch", "identity_mismatch")
        except Exception as exc:
            errors.append(_error("crossref", exc))
    if kind in {"pmid", "pmcid"}:
        query = f"EXT_ID:{value} AND SRC:MED" if kind == "pmid" else "PMCID:" + value
        try:
            response = client.json(EUROPEPMC + "/search", {"query": query, "format": "json", "resultType": "core", "pageSize": 5})
            for item in response.get("resultList", {}).get("result", []):
                paper = normalize_europepmc(item)
                if _matches(paper, expected):
                    return paper, errors
            raise RetrievalError("Identifier not found in Europe PMC", "not_found")
        except Exception as exc:
            errors.append(_error("europepmc", exc))
    if kind in {"doi", "openalex", "pmid"}:
        try:
            target = value if kind == "openalex" else f"{kind}:{value}"
            response = client.json(OPENALEX + "/works/" + quote(target, safe=":"), openalex_params())
            paper = normalize_openalex(response)
            if _matches(paper, expected):
                return paper, errors
            raise RetrievalError("OpenAlex identifier mismatch", "identity_mismatch")
        except Exception as exc:
            errors.append(_error("openalex", exc))
    if kind != "openalex":
        try:
            target = value if kind == "s2" else f"{kind.upper()}:{value.removeprefix('PMC') if kind == 'pmcid' else value}"
            response = client.json(SEMANTIC + "/paper/" + quote(target, safe=":"), {"fields": S2_FIELDS}, semantic_headers())
            paper = normalize_semantic(response)
            if _matches(paper, expected):
                return paper, errors
            raise RetrievalError("Semantic Scholar identifier mismatch", "identity_mismatch")
        except Exception as exc:
            errors.append(_error("semantic_scholar", exc))
    return {"title": "", "ids": expected, mapped: value, "metadata_status": "unresolved"}, errors


def discover(identifier_value, id_type="auto", client=None):
    client = client or Client(max_calls=20)
    paper, errors = lookup(identifier_value, id_type, client)
    ids = dict(paper.get("ids") or {})
    doi_value = ids.get("doi") or doi(paper.get("doi"))
    candidates = []
    skipped = []
    def add(source, url, kind, **extra):
        if url and url.startswith(("https://", "http://")) and not any(c["url"] == url for c in candidates):
            candidates.append({"source": source, "url": url, "kind": kind, **extra})
    if paper.get("pdf_url"):
        add(paper.get("source", "metadata"), paper["pdf_url"], "pdf", license=paper.get("license"))
    if ids.get("arxiv_id"):
        requested_kind, requested_value = identifier(identifier_value, id_type)
        arxiv_value = requested_value if requested_kind == "arxiv" else (paper.get("arxiv_id") or ids["arxiv_id"])
        add("arxiv", "https://arxiv.org/pdf/" + arxiv_value, "pdf", version=arxiv_value)
    if doi_value:
        contact = environment_value("UNPAYWALL_EMAIL")
        if contact:
            try:
                response = client.json("https://api.unpaywall.org/v2/" + quote(doi_value, safe=""), {"email": contact})
                if doi(response.get("doi")) != doi_value:
                    raise RetrievalError("Unpaywall identifier mismatch", "identity_mismatch")
                for location in [response.get("best_oa_location")] + (response.get("oa_locations") or []):
                    if location:
                        add("unpaywall", location.get("url_for_pdf"), "pdf", license=location.get("license"), version=location.get("version"))
                        add("unpaywall", location.get("url_for_landing_page"), "landing", license=location.get("license"), version=location.get("version"))
            except Exception as exc:
                errors.append(_error("unpaywall", exc))
        else:
            skipped.append({"source": "unpaywall", "reason": "UNPAYWALL_EMAIL not configured"})
        try:
            response = client.json(OPENALEX + "/works/" + quote("doi:" + doi_value, safe=":"), openalex_params())
            if doi(response.get("doi")) != doi_value:
                raise RetrievalError("OpenAlex identifier mismatch", "identity_mismatch")
            for location in [response.get("best_oa_location")] + (response.get("locations") or []):
                if location and location.get("is_oa"):
                    add("openalex", location.get("pdf_url"), "pdf", license=location.get("license"))
                    add("openalex", location.get("landing_page_url"), "landing", license=location.get("license"))
        except Exception as exc:
            errors.append(_error("openalex", exc))
    # Europe PMC supplies the DOI/PMID/PMCID crosswalk; verify the returned identity.
    if not ids.get("pmcid") and (doi_value or ids.get("pmid")):
        query = "DOI:" + _query_string(doi_value) if doi_value else f"EXT_ID:{ids['pmid']} AND SRC:MED"
        try:
            response = client.json(EUROPEPMC + "/search", {"query": query, "format": "json", "resultType": "core", "pageSize": 5})
            if "errCode" in response or "resultList" not in response:
                raise RetrievalError("Europe PMC metadata error response", "invalid_response")
            for item in response["resultList"].get("result", []):
                candidate = normalize_europepmc(item)
                if _matches(candidate, ids) and candidate.get("pmcid"):
                    ids.update(candidate["ids"])
                    if not paper.get("title"):
                        paper = candidate
                    break
        except Exception as exc:
            errors.append(_error("europepmc", exc))
    if ids.get("pmcid"):
        pmcid = ids["pmcid"]
        if not pmcid.startswith("PMC"):
            pmcid = "PMC" + pmcid
        ids["pmcid"] = pmcid
        add("europepmc", EUROPEPMC + "/" + pmcid + "/fullTextXML", "jats", availability="unverified")
        add("pmc", NCBI + "/efetch.fcgi", "pmc_jats", pmcid=pmcid, availability="unverified")
    if doi_value:
        try:
            key = environment_value("CORE_API_KEY")
            headers = {"Authorization": "Bearer " + key} if key else {}
            response = client.json("https://api.core.ac.uk/v3/search/works/",
                                   {"q": "doi:" + _query_string(doi_value), "limit": 5}, headers)
            if not isinstance(response.get("results"), list):
                raise RetrievalError("CORE search response missing results", "invalid_response")
            for item in response["results"]:
                if doi(item.get("doi")) != doi_value:
                    continue
                add("core", item.get("downloadUrl"), "pdf", license=item.get("license"))
                if key and str(item.get("id", "")).isdigit():
                    add("core", "https://api.core.ac.uk/v3/works/" + str(item["id"]), "core_text")
            if not key:
                skipped.append({"source": "core_full_text", "reason": "CORE_API_KEY not configured; metadata and links only"})
        except Exception as exc:
            errors.append(_error("core", exc))
    paper["ids"] = ids
    # A constructed endpoint is a candidate, not evidence that open text exists.
    has_oa_link = any(c["kind"] in {"pdf", "landing"} for c in candidates)
    return {"schema_version": "2.1", "paper": paper, "status": "oa_link_found" if has_oa_link else "metadata_only",
            "candidates": candidates, "errors": errors, "skipped": skipped,
            "accessed_at": utc_now(), "provenance": client.provenance, "requests_used": client.calls}


class _PDFLink(HTMLParser):
    def __init__(self):
        super().__init__()
        self.url = None
        self.doi = None
    def handle_starttag(self, tag, attrs):
        if tag != "meta":
            return
        values = dict(attrs)
        name = (values.get("name") or values.get("property") or "").lower()
        if name == "citation_pdf_url":
            self.url = values.get("content")
        if name in {"citation_doi", "dc.identifier", "dc.identifier.doi"}:
            self.doi = doi(values.get("content")) or self.doi


def _pdf_text(payload):
    try:
        import pymupdf
        with pymupdf.open(stream=payload, filetype="pdf") as document:
            return "\n\n".join(page.get_text() for page in document), None
    except ImportError:
        pass
    except Exception:
        return "", "PDF parser could not extract text"
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(payload))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages), None
    except ImportError:
        return "", "PDF saved; install an optional PDF parser separately to extract text"
    except Exception:
        return "", "PDF parser could not extract text"


def _pdf_identity(extracted, paper):
    value = doi(paper.get("doi") or (paper.get("ids") or {}).get("doi"))
    # Limit identity checking to front matter; a reference-list DOI is not identity.
    front = extracted[:7000].casefold()
    title_words = re.findall(r"\w+", (paper.get("title") or "").casefold())
    front_words = set(re.findall(r"\w+", front))
    title_match = len(title_words) >= 5 and sum(word in front_words for word in title_words) / len(title_words) >= 0.9
    return title_match and (not value or value in front or len(title_words) >= 8)


def retrieve(identifier_value, output_dir, id_type="auto", max_calls=30):
    client = Client(max_calls=max_calls)
    report = discover(identifier_value, id_type, client)
    directory = Path(output_dir).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    kind, value = identifier(identifier_value, id_type)
    stem = re.sub(r"[^\w-]+", "_", value)[:90] + "_" + hashlib.sha256(value.encode()).hexdigest()[:8]
    # Do not overwrite prior retrievals.
    prefix = directory / stem
    suffix = 1
    while any(directory.glob(prefix.name + ".*")):
        prefix = directory / f"{stem}_{suffix}"
        suffix += 1
    report["files"] = []
    priorities = {"jats": 0, "pmc_jats": 1, "core_text": 2, "pdf": 3, "landing": 4}
    candidates = sorted(report["candidates"], key=lambda c: priorities[c["kind"]])
    saved_pdf = False
    chosen_copy = None
    for candidate in candidates:
        try:
            candidate_kind = candidate["kind"]
            source = candidate["source"]
            if candidate_kind == "core_text":
                key = environment_value("CORE_API_KEY")
                if not key:
                    continue
                response = client.json(candidate["url"], headers={"Authorization": "Bearer " + key})
                if doi(response.get("doi")) != report["paper"]["ids"].get("doi"):
                    raise RetrievalError("CORE work identifier mismatch", "identity_mismatch")
                extracted = response.get("fullText") or ""
                if not isinstance(extracted, str) or len(extracted.strip()) < 200 or "not available for public api" in extracted.casefold():
                    raise RetrievalError("CORE did not return usable full text", "metadata_only")
                path = prefix.with_suffix(".txt")
                path.write_text(extracted, encoding="utf-8")
                report["files"].append(str(path))
                report.update(status="full_text_parsed", identity_status="identifier_verified", source=source)
                chosen_copy = candidate
                break
            params = ncbi_params({"db": "pmc", "id": candidate["pmcid"].removeprefix("PMC"), "retmode": "xml"}) if candidate_kind == "pmc_jats" else None
            payload, headers, final_url = client.get(candidate["url"], params=params, public=True)
            if candidate_kind in {"jats", "pmc_jats"}:
                expected = {key: val for key, val in report["paper"]["ids"].items() if key in {"doi", "pmid", "pmcid"}}
                parsed = parse_jats(payload, expected)
                if parsed["status"] != "full_text_parsed":
                    raise RetrievalError("JATS contains metadata but no article body", "metadata_only")
                xml_path, md_path = prefix.with_suffix(".xml"), prefix.with_suffix(".md")
                xml_path.write_bytes(payload)
                md_path.write_text("# " + parsed["title"] + "\n\n" + parsed["text"] + "\n", encoding="utf-8")
                report["files"].extend([str(xml_path), str(md_path)])
                report.update(status="full_text_parsed", identity_status="identifier_verified", source=source,
                              sections=parsed["sections"], source_url=safe_url(final_url))
                chosen_copy = candidate
                break
            if not payload.lstrip().startswith(b"%PDF-"):
                parser = _PDFLink()
                parser.feed(payload[:2 * 1024 * 1024].decode("utf-8", errors="replace"))
                expected_doi = report["paper"]["ids"].get("doi")
                if parser.doi and expected_doi and parser.doi != expected_doi:
                    raise RetrievalError("Landing page belongs to another DOI", "identity_mismatch")
                if not parser.url:
                    raise RetrievalError("Returned page is not a PDF and has no citation_pdf_url", "not_full_text")
                payload, headers, final_url = client.get(urljoin(final_url, parser.url), public=True)
                if not payload.lstrip().startswith(b"%PDF-"):
                    raise RetrievalError("PDF URL returned non-PDF content", "not_full_text")
            extracted, note = _pdf_text(payload)
            # A title/abstract preview can match metadata without containing an article body.
            body_evidence = len(extracted.strip()) >= 1500 and (
                len(extracted.strip()) >= 5000 or bool(re.search(
                    r"\b(introduction|methods|methodology|results|discussion|conclusions?)\b", extracted[500:], re.I)))
            verified = body_evidence and _pdf_identity(extracted, report["paper"])
            if saved_pdf and not verified:
                continue
            pdf_path = prefix.with_suffix(".pdf")
            pdf_path.write_bytes(payload)
            if str(pdf_path) not in report["files"]:
                report["files"].append(str(pdf_path))
            saved_pdf = True
            report.update(status="pdf_downloaded", identity_status="requires_review", source=source, source_url=safe_url(final_url))
            chosen_copy = candidate
            if note:
                report.setdefault("notes", []).append(note)
            if verified:
                path = prefix.with_suffix(".txt")
                path.write_text(extracted, encoding="utf-8")
                report["files"].append(str(path))
                report.update(status="full_text_parsed", identity_status="front_matter_match",
                              content_completeness="PDF text extracted; publisher-version completeness unverified")
                break
            report.setdefault("notes", []).append("PDF identity or readable body is not confirmed; inspect before citing its contents")
        except Exception as exc:
            report["errors"].append(_error(candidate["source"], exc))
            if isinstance(exc, RetrievalError) and exc.kind == "call_limit":
                break
    report["requests_used"] = client.calls
    report["provenance"] = client.provenance
    if chosen_copy:
        report["copy_license"] = chosen_copy.get("license")
        report["copy_version"] = chosen_copy.get("version")
    path = prefix.with_suffix(".retrieval.json")
    report["report_path"] = str(path)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
