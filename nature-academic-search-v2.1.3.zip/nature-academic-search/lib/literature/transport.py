"""Bounded HTTP requests, per-host pacing, and credential-free provenance."""

from __future__ import annotations

import email.utils
import ipaddress
import json
import math
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from .configuration import environment_value


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def setting(name):
    """Honor legacy MCP TOML fields while keeping environment values primary."""
    value = environment_value(name)
    if value:
        return value
    aliases = {"NCBI_API_KEY": ("pubmed", "api_key"), "PUBMED_EMAIL": ("pubmed", "email"),
               "CROSSREF_MAILTO": ("crossref", "mailto")}
    if name not in aliases:
        return ""
    base = Path(__file__).resolve().parents[2]
    path = base / "mcp-server" / "config.toml"
    if not path.is_file():
        path = base / "config.toml"
    if not path.is_file():
        return ""
    try:
        try:
            import tomllib
            config = tomllib.loads(path.read_text(encoding="utf-8"))
        except ImportError:
            import toml
            config = toml.load(path)
        section, key = aliases[name]
        value = config.get(section, {}).get(key, "")
        return value if isinstance(value, str) else ""
    except (ImportError, ValueError, OSError):
        return ""


MAX_RETRY_WAIT = 30


class RetrievalError(RuntimeError):
    def __init__(self, message, kind="request_failed", status=None, retry_after=None):
        super().__init__(message)
        self.kind = kind
        self.status = status
        self.retry_after = retry_after


def retry_delay(headers, default):
    value = next((v for k, v in headers.items() if k.lower() == "retry-after"), None)
    if value is None:
        return default
    try:
        pause = float(value)
    except (ValueError, TypeError):
        try:
            pause = email.utils.parsedate_to_datetime(value).timestamp() - time.time()
        except (ValueError, TypeError, OverflowError):
            return default
    return max(0.0, pause) if math.isfinite(pause) else default


def safe_url(url):
    parts = urllib.parse.urlsplit(url)
    private = {"api_key", "apikey", "key", "email", "mailto", "tool", "token",
               "access_token", "insttoken", "signature", "x-amz-signature"}
    query = [(key, "REDACTED" if key.lower() in private or "token" in key.lower() else value)
             for key, value in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)]
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc.split("@")[-1],
                                   parts.path, urllib.parse.urlencode(query), ""))


def public_url(url):
    """Validate publisher/repository URLs before fetching or following redirects."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in {"https", "http"} or not parts.hostname or parts.username:
        raise RetrievalError("Full-text URL must be a public HTTP(S) URL", "invalid_url")
    if parts.port not in (None, 80, 443):
        raise RetrievalError("Nonstandard full-text URL port", "invalid_url")
    try:
        addresses = socket.getaddrinfo(parts.hostname, parts.port or 443, type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(item[4][0]).is_global for item in addresses):
            raise RetrievalError("Full-text URL does not resolve to a public address", "invalid_url")
    except socket.gaierror as exc:
        raise RetrievalError("Could not resolve full-text host", "network") from exc
    return url


class _Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, newurl):
        public_url(newurl)
        old = urllib.parse.urlsplit(request.full_url)
        new = urllib.parse.urlsplit(newurl)
        if old.scheme == "https" and new.scheme != "https":
            raise RetrievalError("HTTPS redirect downgrade rejected", "redirect")
        redirected = super().redirect_request(request, response, code, message, headers, newurl)
        if redirected and old.netloc != new.netloc:
            for key in list(redirected.headers):
                if key.lower() in {"authorization", "x-api-key", "x-els-apikey", "x-els-insttoken"}:
                    del redirected.headers[key]
        return redirected


_pace_lock = threading.Lock()
_next_request = {}
_cooldown_until = {}
_cooldown_status = {}


class Client:
    """A request budget is shared across all sources in one operation."""
    def __init__(self, max_calls=50, timeout=30, max_bytes=32 * 1024 * 1024):
        if max_calls < 1:
            raise ValueError("max_calls must be positive")
        self.max_calls = max_calls
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.calls = 0
        self.provenance = []
        self._lock = threading.Lock()
        self._opener = urllib.request.build_opener(_Redirects())

    def _pace(self, host):
        delay = 0.25
        if "arxiv.org" in host:
            delay = 3.1
        elif "ncbi.nlm.nih.gov" in host:
            delay = 0.11 if setting("NCBI_API_KEY") else 0.35
        elif "semanticscholar.org" in host or "crossref.org" in host:
            delay = 1.1
        elif "core.ac.uk" in host:
            delay = 6.1
        elif "elsevier.com" in host:
            delay = 1.0
        # Recheck after sleeping: another request may have extended the cooldown.
        while True:
            with _pace_lock:
                now = time.monotonic()
                cooldown = _cooldown_until.get(host, now) - now
                if cooldown > MAX_RETRY_WAIT:
                    status = _cooldown_status.get(host, 429)
                    raise RetrievalError(f"Service cooldown remains for {host}",
                                         "rate_limited" if status == 429 else "unavailable",
                                         status, round(cooldown, 3))
                due = max(_next_request.get(host, now), _cooldown_until.get(host, now))
                if due <= now:
                    _next_request[host] = now + delay
                    return
            time.sleep(due - now)

    def get(self, url, params=None, headers=None, public=False):
        if params:
            values = {k: v for k, v in params.items() if v is not None and v != ""}
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(values)
        if public:
            public_url(url)
        host = urllib.parse.urlsplit(url).hostname or ""
        request_headers = {"User-Agent": "nature-academic-search/2.1", **(headers or {})}
        semantic = host == "api.semanticscholar.org"
        attempts = 3 if semantic else 2
        for attempt in range(attempts):
            with self._lock:
                if self.calls >= self.max_calls:
                    raise RetrievalError("Operation reached max_calls", "call_limit")
            self._pace(host)
            with self._lock:
                if self.calls >= self.max_calls:
                    raise RetrievalError("Operation reached max_calls", "call_limit")
                self.calls += 1
            entry = {"url": safe_url(url), "method": "GET", "accessed_at": utc_now()}
            if semantic:
                entry["api_key_sent"] = any(k.lower() == "x-api-key" and bool(v)
                                            for k, v in request_headers.items())
            with self._lock:
                self.provenance.append(entry)
            try:
                request = urllib.request.Request(url, headers=request_headers)
                with self._opener.open(request, timeout=self.timeout) as response:
                    body = response.read(self.max_bytes + 1)
                    entry["http_status"] = response.status
                    entry["final_url"] = safe_url(response.url)
                    if len(body) > self.max_bytes:
                        raise RetrievalError("Response exceeds configured byte limit", "size_limit")
                    return body, dict(response.headers), response.url
            except urllib.error.HTTPError as exc:
                entry["http_status"] = exc.code
                kind = {401: "authentication", 403: "access_denied", 404: "not_found",
                        429: "rate_limited", 503: "unavailable"}.get(exc.code, "http_error")
                entry["error_kind"] = kind
                pause = None
                if exc.code in {429, 503}:
                    pause = retry_delay(exc.headers or {}, 5 * 2 ** attempt if semantic else 3)
                    entry["retry_after_seconds"] = pause
                    with _pace_lock:
                        until = time.monotonic() + pause
                        if until >= _cooldown_until.get(host, 0):
                            _cooldown_until[host] = until
                            _cooldown_status[host] = exc.code
                    if pause <= MAX_RETRY_WAIT and attempt + 1 < attempts and self.calls < self.max_calls:
                        entry["retry_scheduled"] = True
                        continue
                raise RetrievalError(f"HTTP {exc.code} from {host}", kind, exc.code, pause) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                entry["error_kind"] = "network"
                raise RetrievalError(f"Network request failed for {host}", "network") from exc

    def json(self, url, params=None, headers=None):
        body, _, _ = self.get(url, params, {"Accept": "application/json", **(headers or {})})
        try:
            return json.loads(body)
        except (ValueError, UnicodeError) as exc:
            raise RetrievalError("Response was not valid JSON", "invalid_response") from exc


def openalex_params(params=None):
    result = dict(params or {})
    key = environment_value("OPENALEX_API_KEY")
    mail = environment_value("OPENALEX_MAILTO") or setting("CROSSREF_MAILTO")
    if key:
        result["api_key"] = key
    if mail:
        result["mailto"] = mail
    return result


def semantic_headers():
    key = environment_value("S2_API_KEY", aliases=("SEMANTIC_SCHOLAR_API_KEY",))
    return {"x-api-key": key} if key else {}
