"""Identifiers, conservative deduplication, and section-aware XML parsing."""

from __future__ import annotations

import copy
import html
from html.parser import HTMLParser
import re
import urllib.parse
import xml.etree.ElementTree as ET

from .transport import RetrievalError, utc_now


class _MetadataText(HTMLParser):
    """Remove known metadata markup while preserving literal comparison signs."""
    tags = frozenset("p br div span b i em strong u s sup sub italic bold underline "
                     "title sec abstract label jats-p jats-title math mrow mi mn mo msup msub "
                     "mfrac semantics annotation tex-math inline-formula disp-formula".split())

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)

    def handle_starttag(self, tag, attrs):
        self.parts.append(" " if tag.rsplit(":", 1)[-1] in self.tags else self.get_starttag_text())

    def handle_endtag(self, tag):
        self.parts.append(" " if tag.rsplit(":", 1)[-1] in self.tags else f"</{tag}>")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)


def text(value):
    if value is None:
        return ""
    if isinstance(value, ET.Element):
        return " ".join(html.unescape(" ".join(value.itertext())).split())
    parser = _MetadataText()
    parser.feed(str(value))
    parser.close()
    return " ".join("".join(parser.parts).split())


def doi(value):
    value = urllib.parse.unquote(str(value or "").strip())
    value = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi\s*:\s*)", "", value, flags=re.I)
    return value.lower() if re.fullmatch(r"10\.\d{4,9}/\S+", value) else ""


def identifier(value, kind="auto"):
    value = str(value).strip()
    if kind != "auto":
        kind = kind.lower()
        value = re.sub(r"^(?:doi|pmid|pmcid|arxiv|openalex|s2):", "", value, flags=re.I)
    else:
        if doi(value):
            kind = "doi"
        elif re.match(r"^(?:PMCID:)?PMC\d+$", value, re.I):
            kind = "pmcid"
        elif re.match(r"^(?:PMID:)?\d+$", value, re.I):
            kind = "pmid"
        elif re.match(r"^(?:https?://openalex.org/)?W\d+$", value, re.I):
            kind = "openalex"
        elif re.match(r"^(?:S2:)?[a-f0-9]{40}$", value, re.I):
            kind = "s2"
        else:
            kind = "arxiv"
        value = re.sub(r"^(?:pmid|pmcid|arxiv|s2):", "", value, flags=re.I)
    if kind == "doi":
        value = doi(value)
    elif kind == "pmid":
        value = value if re.fullmatch(r"\d+", value) else ""
    elif kind == "pmcid":
        value = value.upper()
        value = "PMC" + value if value.isdigit() else value
        value = value if re.fullmatch(r"PMC\d+", value) else ""
    elif kind == "arxiv":
        value = re.sub(r"^https?://arxiv.org/(?:abs|pdf)/", "", value, flags=re.I)
        value = re.sub(r"\.pdf$", "", value)
        if not re.fullmatch(r"(?:\d{4}\.\d{4,5}|[a-zA-Z.-]+/\d{7})(?:v\d+)?", value):
            value = ""
    elif kind == "openalex":
        value = value.rsplit("/", 1)[-1].upper()
        value = value if re.fullmatch(r"W\d+", value) else ""
    elif kind == "s2":
        value = value if re.fullmatch(r"[a-fA-F0-9]{40}", value) else ""
    else:
        value = ""
    if not value:
        raise ValueError("Unsupported or invalid paper identifier")
    return kind, value


def xml_root(payload):
    if isinstance(payload, bytes):
        payload = payload.decode("utf-8-sig", errors="replace")
    if payload.strip().startswith("Rate exceeded"):
        raise RetrievalError("arXiv returned a rate-limit response", "rate_limited")
    if "<!ENTITY" in payload.upper():
        raise RetrievalError("XML contains unsupported entity declarations", "invalid_response")
    try:
        root = ET.fromstring(payload)
    except ET.ParseError as exc:
        raise RetrievalError("Response was not valid XML", "invalid_response") from exc
    # Strip namespaces once so JATS, Atom, and MathML can be read consistently.
    for node in root.iter():
        node.tag = node.tag.rsplit("}", 1)[-1]
    return root


def reconstruct_abstract(index):
    if not isinstance(index, dict):
        return "", []
    positions = {}
    for word, offsets in index.items():
        if isinstance(offsets, list):
            for offset in offsets:
                if type(offset) is int and offset >= 0:
                    positions.setdefault(offset, []).append(word)
    notes = []
    if any(len(words) > 1 for words in positions.values()):
        notes.append("Abstract has conflicting token positions; ordering is uncertain")
    if positions and (min(positions) != 0 or max(positions) + 1 != len(positions)):
        notes.append("Abstract index has missing positions")
    return " ".join(word for offset in sorted(positions) for word in positions[offset]), notes


def record(source, **fields):
    item = {"title": "", "authors": [], "year": None, "doi": "", "journal": "",
            "abstract": "", "url": "", "source": source, "sources": [source],
            "ids": {}, "citation_counts": {}, "full_text_status": "not_checked", **fields}
    item["title"] = text(item.get("title"))
    item["abstract"] = text(item.get("abstract"))
    item["doi"] = doi(item.get("doi"))
    if item.get("pmcid"):
        item["pmcid"] = str(item["pmcid"]).rstrip("/").rsplit("/", 1)[-1].upper()
        if item["pmcid"].isdigit():
            item["pmcid"] = "PMC" + item["pmcid"]
    if item.get("pmid"):
        item["pmid"] = str(item["pmid"]).rstrip("/").rsplit("/", 1)[-1]
    for key in ("doi", "pmid", "pmcid", "arxiv_id", "openalex_id", "semantic_scholar_id"):
        if item.get(key):
            value = str(item[key])
            if key == "arxiv_id":
                item["arxiv_version"] = re.search(r"v(\d+)$", value).group(1) if re.search(r"v(\d+)$", value) else None
                value = re.sub(r"v\d+$", "", value)
            item["ids"][key] = value
    count = item.get("cited_by_count")
    if count is not None:
        item["citation_counts"][source] = {"count": count, "accessed_at": utc_now()}
    return item


def _title_key(item):
    return " ".join(re.findall(r"\w+", item.get("title", "").casefold()))


def _author_key(item):
    authors = item.get("authors") or []
    first = authors[0] if authors else ""
    if isinstance(first, dict):
        first = first.get("name", "")
    return re.sub(r"\W+", "", str(first).casefold())


def _is_preprint(item):
    kind = str(item.get("type", "")).lower()
    return item.get("source") == "arxiv" or kind in {"preprint", "posted-content"}


def _conflicting_ids(left, right):
    a, b = left.get("ids") or {}, right.get("ids") or {}
    return any(a[key] != b[key] for key in ("doi", "pmid", "pmcid") if a.get(key) and b.get(key))


def _compatible(left, right):
    return (not _conflicting_ids(left, right) and _is_preprint(left) == _is_preprint(right)
            and not (left.get("arxiv_version") and right.get("arxiv_version")
                     and left["arxiv_version"] != right["arxiv_version"]))


def _source_record(item):
    return {"source": item["source"], "ids": copy.deepcopy(item.get("ids") or {}),
            "url": item.get("url"), "title": item["title"], "arxiv_version": item.get("arxiv_version")}


def _merge_record(old, item):
    old["sources"] = list(dict.fromkeys(old["sources"] + item["sources"]))
    for evidence in item.get("source_records") or [_source_record(item)]:
        if evidence not in old["source_records"]:
            old["source_records"].append(copy.deepcopy(evidence))
    old["ids"].update({k: v for k, v in item["ids"].items() if k not in old["ids"]})
    old["citation_counts"].update(item.get("citation_counts", {}))
    for key in ("related_versions", "possible_duplicate_ids"):
        for value in item.get(key, []):
            if value not in old.setdefault(key, []):
                old[key].append(copy.deepcopy(value))
    for key, value in item.items():
        if not old.get(key) and value is not None:
            old[key] = copy.deepcopy(value)
    if len(item.get("abstract") or "") > len(old.get("abstract") or ""):
        old["abstract"] = item["abstract"]
    if len(item.get("authors") or []) > len(old.get("authors") or []):
        old["authors"] = item["authors"]


def _relate(left, right):
    for item, other in ((left, right), (right, left)):
        relation = {"ids": copy.deepcopy(other.get("ids") or {}), "source": other["source"]}
        if other.get("arxiv_version"):
            relation["arxiv_version"] = other["arxiv_version"]
        if relation not in item.setdefault("related_versions", []):
            item["related_versions"].append(relation)


def deduplicate(items):
    """Merge exact identities; retain publication versions and ambiguous matches."""
    merged = []
    keys = {}
    for original in items:
        item = copy.deepcopy(original)
        # Keep source identities independent from the growing merged ID map.
        item["source_records"] = copy.deepcopy(original.get("source_records") or [_source_record(original)])
        ids = item.get("ids") or {}
        strong = [(name, value) for name, value in ids.items() if value]
        candidate_indices = {index for key in strong for index in keys.get(key, set())}
        target = None
        for index in sorted(candidate_indices):
            old = merged[index]
            if old is None:
                continue
            if not _compatible(old, item):
                _relate(old, item)
            elif target is None:
                target = index
            elif _compatible(merged[target], old):
                # A later DOI/PMID crosswalk can join two earlier records.
                _merge_record(merged[target], old)
                merged[index] = None
                for key, value in old["ids"].items():
                    bucket = keys.get((key, value), set())
                    bucket.discard(index)
                    bucket.add(target)
            else:
                _relate(merged[target], old)
        if target is None and not candidate_indices:
            title = _title_key(item)
            if title and _author_key(item) and item.get("year"):
                for index, old in enumerate(merged):
                    if old is None:
                        continue
                    if title == _title_key(old) and _author_key(item) == _author_key(old) and item["year"] == old.get("year"):
                        if (not item.get("doi") or not old.get("doi")) and _compatible(old, item):
                            target = index
                            break
                        item.setdefault("possible_duplicate_ids", []).append(old.get("ids", {}))
        if target is None:
            target = len(merged)
            merged.append(item)
        else:
            _merge_record(merged[target], item)
        for key in strong:
            keys.setdefault(key, set()).add(target)
    return [item for item in merged if item is not None]


def parse_jats(payload, expected_ids=None):
    root = xml_root(payload)
    article = root if root.tag == "article" else root.find(".//article")
    if article is None:
        raise RetrievalError("JATS response contains no article", "invalid_response")
    ids = {}
    for node in article.findall("./front/article-meta/article-id"):
        kind = node.get("pub-id-type", "")
        value = text(node)
        if kind == "doi":
            ids["doi"] = doi(value)
        elif kind in {"pmc", "pmcid"}:
            ids["pmcid"] = value if value.startswith("PMC") else "PMC" + value
        elif kind == "pmid":
            ids["pmid"] = value
    expected_ids = expected_ids or {}
    matches = [key for key in expected_ids if key in ids and ids[key] == expected_ids[key]]
    conflicts = [key for key in expected_ids if key in ids and ids[key] != expected_ids[key]]
    if conflicts or (expected_ids and not matches):
        raise RetrievalError("JATS identifiers do not confirm the requested paper", "identity_mismatch")
    title = text(article.find("./front/article-meta/title-group/article-title"))
    body = article.find("body")
    if body is None or not text(body):
        return {"status": "metadata_only", "title": title, "ids": ids, "text": "", "sections": []}
    blocks = []
    sections = []
    def visit(node):
        for child in node:
            if child.tag == "sec":
                visit(child)
            elif child.tag == "title":
                heading = text(child)
                sections.append(heading)
                blocks.append("## " + heading)
            elif child.tag in {"p", "fig", "table-wrap", "disp-formula", "list", "boxed-text", "statement"}:
                value = text(child)
                if value:
                    blocks.append(value)
            else:
                visit(child)
    visit(body)
    return {"status": "full_text_parsed", "title": title, "ids": ids,
            "sections": sections, "text": "\n\n".join(blocks) or text(body)}
