"""Multi-source search with bounded pagination and separate source counts."""

from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from urllib.parse import quote, urlsplit

from .records import deduplicate, doi, record, reconstruct_abstract, text, xml_root
from .configuration import elsevier_settings
from .transport import MAX_RETRY_WAIT, Client, RetrievalError, openalex_params, semantic_headers, setting, utc_now

OPENALEX = "https://api.openalex.org"
SEMANTIC = "https://api.semanticscholar.org/graph/v1"
EUROPEPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest"
NCBI = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
S2_FIELDS = "paperId,title,authors,year,abstract,externalIds,citationCount,publicationDate,journal,venue,url,openAccessPdf,publicationTypes"
SOURCES = ("openalex", "semantic_scholar", "crossref", "arxiv", "pubmed", "europepmc", "scopus", "sciencedirect")


@dataclass
class Page:
    records: list
    total: int | None
    next_state: object = None
    count_kind: str = "reported"
    notes: list = field(default_factory=list)
    raw_count: int | None = None
    query_as_executed: str | None = None
    retrieval_method: str | None = None


def integer(value):
    try:
        return int(value) if value is not None else None
    except (ValueError, TypeError):
        return None


def shape(condition, source):
    if not condition:
        raise RetrievalError(f"{source} returned an unexpected response shape", "invalid_response")


def normalize_openalex(work):
    abstract, notes = reconstruct_abstract(work.get("abstract_inverted_index"))
    location = work.get("primary_location") or {}
    source = location.get("source") or {}
    best = work.get("best_oa_location") or {}
    ids = work.get("ids") or {}
    return record("openalex", title=work.get("title"), doi=work.get("doi"),
                  authors=[(a.get("author") or {}).get("display_name", "") for a in work.get("authorships") or []],
                  year=work.get("publication_year"), publication_date=work.get("publication_date"),
                  journal=source.get("display_name", ""), abstract=abstract, abstract_warnings=notes,
                  openalex_id=str(work.get("id") or "").rsplit("/", 1)[-1],
                  pmid=str(ids.get("pmid") or "").rstrip("/").rsplit("/", 1)[-1],
                  pmcid=str(ids.get("pmcid") or "").rstrip("/").rsplit("/", 1)[-1],
                  cited_by_count=work.get("cited_by_count"), relevance_score=work.get("relevance_score"),
                  url=location.get("landing_page_url") or work.get("doi") or work.get("id"),
                  oa_url=best.get("pdf_url") or best.get("landing_page_url"),
                  pdf_url=best.get("pdf_url"), license=best.get("license"), type=work.get("type"))


def normalize_semantic(work):
    ids = work.get("externalIds") or {}
    journal = work.get("journal") or {}
    oa = work.get("openAccessPdf") or {}
    return record("semantic_scholar", title=work.get("title"), doi=ids.get("DOI"),
                  authors=[a.get("name", "") for a in work.get("authors") or []],
                  year=work.get("year"), abstract=work.get("abstract"), journal=journal.get("name") or work.get("venue"),
                  semantic_scholar_id=work.get("paperId"), arxiv_id=ids.get("ArXiv"),
                  pmid=ids.get("PubMed"), pmcid=ids.get("PubMedCentral"),
                  publication_date=work.get("publicationDate"), cited_by_count=work.get("citationCount"),
                  url=work.get("url"), pdf_url=oa.get("url"), oa_url=oa.get("url"),
                  type="preprint" if "Preprint" in (work.get("publicationTypes") or []) else None)


def normalize_crossref(work):
    dates = (work.get("published") or work.get("published-print") or work.get("published-online") or {}).get("date-parts") or [[]]
    date = dates[0] if dates else []
    return record("crossref", title=(work.get("title") or [""])[0], doi=work.get("DOI"),
                  authors=[text(a.get("name") or " ".join(v for v in (a.get("given"), a.get("family")) if v))
                           for a in work.get("author") or []],
                  year=date[0] if date else None, publication_date="-".join(str(v).zfill(2) for v in date),
                  abstract=work.get("abstract"), journal=(work.get("container-title") or [""])[0],
                  cited_by_count=work.get("is-referenced-by-count"), url=work.get("URL"), type=work.get("type"),
                  relations=work.get("relation") or {}, publication_updates=work.get("update-to") or [])


def normalize_europepmc(work):
    info = work.get("journalInfo") or {}
    names = (work.get("authorList") or {}).get("author") or []
    authors = [a.get("fullName") or a.get("collectiveName") or "" for a in names]
    if not authors:
        authors = [a.strip() for a in (work.get("authorString") or "").split(",") if a.strip()]
    source_id = str(work.get("source") or "") + "/" + str(work.get("id") or "")
    result = record("europepmc", title=work.get("title"), authors=authors,
                    year=integer(work.get("pubYear")), doi=work.get("doi"),
                    abstract=work.get("abstractText"), journal=(info.get("journal") or {}).get("title") or work.get("journalTitle"),
                    pmid=work.get("pmid") or (work.get("id") if work.get("source") == "MED" else ""),
                    pmcid=work.get("pmcid"), cited_by_count=integer(work.get("citedByCount")),
                    publication_date=work.get("firstPublicationDate"),
                    url="https://europepmc.org/article/" + source_id)
    result["ids"]["europepmc_id"] = source_id
    return result


def ncbi_params(params):
    result = dict(params)
    if setting("NCBI_API_KEY"):
        result["api_key"] = setting("NCBI_API_KEY")
    if setting("PUBMED_EMAIL"):
        result["email"] = setting("PUBMED_EMAIL")
    return result


def _elsevier_headers():
    try:
        keys, tokens, _ = elsevier_settings()
    except ValueError as exc:
        raise RetrievalError(str(exc), "configuration") from None
    if not keys:
        raise RetrievalError("Elsevier API key is not configured", "missing_credentials")
    headers = {"X-ELS-APIKey": keys[0]}
    if tokens:
        headers["X-ELS-Insttoken"] = tokens[0]
    return headers


def arxiv_query(query, native=False):
    """Preserve native field queries; qualify plain terms without losing logic."""
    if native or re.search(r"\b(?:all|ti|au|abs|co|jr|cat|rn|id|submittedDate):", query, re.I):
        return query
    if len(re.findall(r'(?<!\\)"', query)) % 2:
        raise RetrievalError("Unbalanced quotes in arXiv query", "query_error")
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()"]+', query)
    output, depth, expect_term = [], 0, True
    for token in tokens:
        operator = token.upper()
        if operator in {"AND", "OR", "ANDNOT", "NOT"}:
            if operator == "NOT" and output and output[-1] == "AND":
                output[-1] = "ANDNOT"
                continue
            if expect_term:
                raise RetrievalError("arXiv Boolean operators require a preceding term", "query_error")
            output.append("ANDNOT" if operator == "NOT" else operator)
            expect_term = True
        elif token == ")":
            if depth == 0 or expect_term:
                raise RetrievalError("Unbalanced or empty group in arXiv query", "query_error")
            output.append(token)
            depth -= 1
        else:
            if not expect_term:
                output.append("AND")
            if token == "(":
                depth += 1
                output.append(token)
                expect_term = True
            else:
                output.append("all:" + token)
                expect_term = False
    if depth or (tokens and expect_term):
        raise RetrievalError("Incomplete arXiv query", "query_error")
    return " ".join(output)


def fetch_page(source, query, state, size, client, options):
    year = options.get("year_from")
    if source == "openalex":
        filters = []
        if year:
            filters.append(f"from_publication_date:{year}-01-01")
        if options.get("author_id"):
            ids = "|".join(v.rsplit("/", 1)[-1] for v in options["author_id"].split("|"))
            filters.append("author.id:" + ids)
        params = {"search": query, "per_page": min(size, 200), "cursor": state or "*",
                  "filter": ",".join(filters)}
        if not query:
            params["sort"] = "publication_date:desc" if options.get("sort") == "publication_date" else "cited_by_count:desc"
        data = client.json(OPENALEX + "/works", openalex_params(params))
        shape(isinstance(data, dict) and isinstance(data.get("results"), list) and isinstance(data.get("meta"), dict), source)
        rows = data["results"]
        return Page([normalize_openalex(w) for w in rows], integer(data["meta"].get("count")),
                    data["meta"].get("next_cursor") if rows else None)
    if source == "semantic_scholar":
        bulk = options.get("mode") == "comprehensive"
        notes = []
        method = "bulk" if bulk else "relevance"
        params = {"query": query, "fields": S2_FIELDS, "year": f"{year}-" if year else None}
        if bulk:
            params.update({"token": state, "sort": "paperId:asc"})
        else:
            params.update({"offset": state or 0, "limit": min(size, 100)})
        headers = semantic_headers()
        try:
            data = client.json(SEMANTIC + ("/paper/search/bulk" if bulk else "/paper/search"), params, headers)
        except RetrievalError as exc:
            # Only plain terms can transfer to bulk without activating new operators.
            # Preserve server cooldowns and never replace an in-progress result stream.
            if (bulk or state not in (None, 0) or exc.kind != "rate_limited"
                    or (exc.retry_after is not None and exc.retry_after > MAX_RETRY_WAIT)
                    or not re.fullmatch(r"[\w\s]+", query)):
                raise
            bulk, method = True, "bulk_after_429"
            params.pop("offset", None)
            params.pop("limit", None)
            params["sort"] = "publicationDate:desc" if options.get("sort") == "publication_date" else "citationCount:desc"
            data = client.json(SEMANTIC + "/paper/search/bulk", params, headers)
            notes.append("Semantic Scholar relevance search remained rate limited; used bulk title/abstract matching "
                         "with all query terms required, ordered by " + params["sort"] +
                         "; matching and order differ from relevance search")
        shape(isinstance(data, dict) and isinstance(data.get("data"), list), source)
        rows = data["data"]
        return Page([normalize_semantic(w) for w in rows], integer(data.get("total")),
                    data.get("token" if bulk else "next") if rows else None,
                    "estimate" if bulk else "reported", notes=notes, raw_count=len(rows),
                    query_as_executed=query, retrieval_method=method)
    if source == "crossref":
        filters = []
        if year:
            filters.append(f"from-pub-date:{year}-01-01")
        if options.get("filter_type"):
            filters.append("type:" + options["filter_type"])
        params = {"query": query, "rows": min(size, 1000), "cursor": state or "*",
                  "filter": ",".join(filters), "mailto": setting("CROSSREF_MAILTO")}
        payload = client.json("https://api.crossref.org/works", params)
        data = payload.get("message") if isinstance(payload, dict) else None
        shape(isinstance(data, dict) and isinstance(data.get("items"), list), source)
        rows = data["items"]
        return Page([normalize_crossref(w) for w in rows], integer(data.get("total-results")),
                    data.get("next-cursor") if rows else None)
    if source == "arxiv":
        actual = arxiv_query(query, options.get("native_query", False))
        if year:
            actual = f"({actual}) AND submittedDate:[{year}01010000 TO 999912312359]"
        params = {"search_query": actual, "start": state or 0, "max_results": min(size, 100),
                  "sortBy": "relevance", "sortOrder": "descending"}
        if options.get("arxiv_ids"):
            params = {"id_list": options["arxiv_ids"], "max_results": min(size, 100)}
        payload, _, _ = client.get("https://export.arxiv.org/api/query", params)
        root = xml_root(payload)
        shape(root.tag == "feed", source)
        rows = []
        for entry in root.findall("entry"):
            if text(entry.find("title")) == "Error":
                raise RetrievalError("arXiv returned an error entry with HTTP 200", "query_error")
            raw_id = text(entry.find("id"))
            arxiv_id = re.sub(r"^https?://arxiv.org/abs/", "", raw_id)
            links = entry.findall("link")
            pdf = next((link.get("href") for link in links if link.get("type") == "application/pdf"), None)
            published = text(entry.find("published"))
            rows.append(record("arxiv", title=text(entry.find("title")), arxiv_id=arxiv_id,
                               doi=text(entry.find("doi")), authors=[text(a.find("name")) for a in entry.findall("author")],
                               year=integer(published[:4]), publication_date=published,
                               abstract=text(entry.find("summary")), journal=text(entry.find("journal_ref")),
                               url=raw_id, pdf_url=pdf, oa_url=pdf, type="preprint"))
        total = integer(text(root.find("totalResults")))
        offset = (state or 0) + len(rows)
        return Page(rows, total, offset if rows and (total is None or offset < total) else None,
                    query_as_executed=text(root.find("title")))
    if source == "europepmc":
        actual = f"({query}) AND FIRST_PDATE:[{year}-01-01 TO 9999-12-31]" if year else query
        data = client.json(EUROPEPMC + "/search", {"query": actual, "format": "json", "resultType": "core",
                                                  "pageSize": min(size, 1000), "cursorMark": state or "*"})
        shape(isinstance(data, dict) and "errCode" not in data and isinstance(data.get("resultList"), dict), source)
        rows = data["resultList"].get("result") or []
        cursor = data.get("nextCursorMark")
        return Page([normalize_europepmc(w) for w in rows], integer(data.get("hitCount")),
                    cursor if rows and cursor != state else None,
                    query_as_executed=(data.get("request") or {}).get("queryString"))
    if source == "pubmed":
        actual = f"({query}) AND {year}:3000[dp]" if year else query
        data = client.json(NCBI + "/esearch.fcgi", ncbi_params({"db": "pubmed", "term": actual, "retmode": "json",
                           "retstart": state or 0, "retmax": min(size, 200), "sort": "relevance"}))
        result = data.get("esearchresult") if isinstance(data, dict) else None
        shape(isinstance(result, dict) and "ERROR" not in data and "errorlist" not in result and isinstance(result.get("idlist"), list), source)
        ids = result["idlist"]
        total = integer(result.get("count"))
        if not ids:
            return Page([], total)
        payload, _, _ = client.get(NCBI + "/efetch.fcgi", ncbi_params({"db": "pubmed", "id": ",".join(ids), "retmode": "xml"}))
        root = xml_root(payload)
        shape(root.tag == "PubmedArticleSet", source)
        rows = []
        for node in root.findall("PubmedArticle"):
            citation = node.find("MedlineCitation")
            article = node.find("./MedlineCitation/Article")
            if article is None:
                continue
            mapped = {e.get("IdType"): text(e) for e in node.findall("./PubmedData/ArticleIdList/ArticleId")}
            if not mapped.get("doi"):
                mapped["doi"] = text(article.find("./ELocationID[@EIdType='doi']"))
            pmid = text(citation.find("PMID"))
            date = article.find("./Journal/JournalIssue/PubDate")
            date_text = text(date)
            match = re.search(r"\b(\d{4})\b", date_text)
            names = [text(a.find("ForeName")) + " " + text(a.find("LastName")) if a.find("LastName") is not None else text(a.find("CollectiveName"))
                     for a in article.findall("./AuthorList/Author")]
            rows.append(record("pubmed", title=text(article.find("ArticleTitle")), authors=[n.strip() for n in names],
                               year=int(match.group(1)) if match else None, doi=mapped.get("doi"), pmid=pmid, pmcid=mapped.get("pmc"),
                               abstract=" ".join(text(a) for a in article.findall("./Abstract/AbstractText")),
                               journal=text(article.find("./Journal/Title")), url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"))
        offset = (state or 0) + len(ids)
        notes = [] if len(rows) == len(ids) else ["Some PubMed records could not be normalized (including book records)"]
        return Page(rows, total, offset if total is None or offset < min(total, 10000) else None,
                    notes=notes + (["PubMed eSearch retrieval ceiling reached"] if total and total > 10000 and offset >= 10000 else []),
                    raw_count=len(ids), query_as_executed=result.get("querytranslation"))
    if source in {"scopus", "sciencedirect"}:
        actual = query
        if year and source == "scopus":
            actual = f"({query}) AND PUBYEAR > {year - 1}"
        params = {"query": actual, "count": min(size, 25), "start": state or 0, "view": "STANDARD"}
        if year and source == "sciencedirect":
            params["date"] = f"{year}-"
        data = client.json("https://api.elsevier.com/content/search/" + source, params, _elsevier_headers())
        result = data.get("search-results") if isinstance(data, dict) else None
        shape(isinstance(result, dict), source)
        total = integer(result.get("opensearch:totalResults"))
        entries = result.get("entry") or []
        if isinstance(entries, dict):
            entries = [entries]
        if total == 0:
            return Page([], 0)
        shape(all(isinstance(e, dict) and "error" not in e for e in entries), source)
        rows = []
        for work in entries:
            names = [a.get("authname") or a.get("$", "") for a in work.get("author") or []]
            if not names and work.get("dc:creator"):
                names = [work["dc:creator"]]
            links = work.get("link") or []
            if isinstance(links, dict):
                links = [links]
            date = work.get("prism:coverDate") or ""
            item = record(source, title=work.get("dc:title"), authors=names, doi=work.get("prism:doi"),
                          year=integer(date[:4]), publication_date=date, journal=work.get("prism:publicationName"),
                          abstract=work.get("dc:description"), cited_by_count=integer(work.get("citedby-count")),
                          url=next((link.get("@href") for link in links if link.get("@ref") in {"scopus", "scidir"}), ""))
            if work.get("eid"):
                item["ids"]["scopus_eid"] = work["eid"]
            if work.get("pii"):
                item["ids"]["pii"] = work["pii"]
            item["author_list_status"] = "source_reported" if work.get("author") else "partial_or_missing"
            rows.append(item)
        offset = (state or 0) + len(entries)
        return Page(rows, total, offset if rows and (total is None or offset < total) else None)
    raise ValueError("Unsupported source: " + source)


def select_sources(domain="general", mode="quick"):
    choices = {
        "general": ["openalex", "semantic_scholar", "crossref"],
        "engineering": ["openalex", "semantic_scholar", "arxiv", "crossref"],
        "biomedical": ["pubmed", "europepmc", "openalex"],
        "preprints": ["arxiv", "semantic_scholar", "openalex"],
    }
    if domain not in choices:
        raise ValueError("Unknown domain")
    values = choices[domain]
    return values if mode == "comprehensive" else values[:3]


def search(query, sources=None, mode="quick", limit=10, max_records=1000, max_calls=50,
           year_from=None, sort="relevance_score", domain="general", author_id=None,
           filter_type=None, source_queries=None, client=None):
    """Return a report; max_records is a global retained-record budget before dedup."""
    if mode not in {"quick", "comprehensive"}:
        raise ValueError("mode must be quick or comprehensive")
    if limit < 1 or max_records < 1 or max_calls < 1:
        raise ValueError("Search limits must be positive")
    if sort not in {"relevance_score", "cited_by_count", "publication_date"}:
        raise ValueError("Unsupported sort order")
    if year_from is not None and not 1000 <= year_from <= 9999:
        raise ValueError("year_from must be a four-digit year")
    if not query and not author_id:
        raise ValueError("Provide a query or an OpenAlex author ID")
    if isinstance(sources, str):
        sources = [v.strip() for v in sources.split(",") if v.strip()]
    selected = list(dict.fromkeys(s.strip() for s in (sources or (["openalex"] if author_id else select_sources(domain, mode)))))
    if any(source not in SOURCES for source in selected):
        raise ValueError("Unknown source; supported: " + ", ".join(SOURCES))
    if author_id and selected != ["openalex"]:
        raise ValueError("OpenAlex author IDs require sources=['openalex']; cross-database author matching is not automatic")
    source_queries = source_queries or {}
    if any(source not in selected for source in source_queries):
        raise ValueError("source_queries contains a source not selected for this search")
    client = client or Client(max_calls=max_calls)
    options = dict(year_from=year_from, author_id=author_id, mode=mode, sort=sort, filter_type=filter_type)
    stats = {source: {"query": source_queries.get(source, query or ""), "reported_total": None,
                      "count_kind": "reported", "received": 0, "normalized": 0, "retained": 0,
                      "pages": 0, "complete": False, "stop_reason": None, "notes": []}
             for source in selected}
    states = {source: None for source in selected}
    page_sizes = {}
    seen_states = {source: set() for source in selected}
    seen_records = {source: set() for source in selected}
    all_records = []
    errors = []
    active = list(selected)
    with ThreadPoolExecutor(max_workers=min(4, len(selected))) as executor:
        while active:
            remaining = max_records - len(all_records)
            if remaining <= 0:
                for source in active:
                    stats[source]["stop_reason"] = "record_limit"
                break
            # Bound a whole round so parallel first pages cannot consume unbounded work.
            batch = active[:remaining]
            share = max(1, remaining // len(batch))
            size = min(100 if mode == "comprehensive" else limit, share)
            # Cursor APIs may bind the cursor to every original query parameter,
            # including page size. Crop retained rows after fetching the final page.
            futures = {source: executor.submit(fetch_page, source, stats[source]["query"], states[source],
                                                page_sizes.setdefault(source, size), client,
                                                {**options, "native_query": source in source_queries})
                       for source in batch}
            again = []
            # Fixed-size bulk pages can exceed the allocation; retain other sources
            # first so one 1,000-record bulk page does not erase their first pages.
            for source in sorted(batch, key=lambda s: s == "semantic_scholar"):
                stat = stats[source]
                try:
                    page = futures[source].result()
                except Exception as exc:
                    kind = exc.kind if isinstance(exc, RetrievalError) else "invalid_response"
                    message = str(exc) if isinstance(exc, RetrievalError) else f"{source} response processing failed ({type(exc).__name__})"
                    error = {"source": source, "kind": kind, "message": message}
                    if isinstance(exc, RetrievalError):
                        if exc.status is not None:
                            error["http_status"] = exc.status
                        if exc.retry_after is not None:
                            error["retry_after_seconds"] = exc.retry_after
                    errors.append(error)
                    stat["stop_reason"] = kind
                    continue
                stat["pages"] += 1
                raw_count = page.raw_count if page.raw_count is not None else len(page.records)
                stat["received"] += raw_count
                stat["normalized"] += len(page.records)
                stat["count_kind"] = page.count_kind
                if page.query_as_executed:
                    stat["query_as_executed"] = page.query_as_executed
                if page.retrieval_method:
                    stat["retrieval_method"] = page.retrieval_method
                if stat["reported_total"] is None:
                    stat["reported_total"] = page.total
                elif page.total is not None and page.total != stat["reported_total"]:
                    stat["notes"].append("Source total changed during pagination")
                stat["notes"].extend(page.notes)
                unique_page = []
                for item in page.records:
                    identity = (tuple(sorted((item.get("ids") or {}).items())) or
                                (item.get("title"), tuple(item.get("authors") or []), item.get("year")))
                    identity = (identity, item.get("arxiv_version"))
                    if identity not in seen_records[source]:
                        seen_records[source].add(identity)
                        item["source_rank"] = len(seen_records[source])
                        item["source_records"] = [{"source": source, "ids": dict(item.get("ids") or {}),
                                                   "url": item.get("url"), "title": item.get("title"),
                                                   "arxiv_version": item.get("arxiv_version")}]
                        unique_page.append(item)
                take = min(len(unique_page), max_records - len(all_records))
                if mode == "quick":
                    take = min(take, limit)
                all_records.extend(unique_page[:take])
                stat["retained"] += take
                known = stat["reported_total"]
                finished = page.next_state is None
                reached_total = known is not None and page.count_kind != "estimate" and stat["received"] >= known
                if take < len(unique_page):
                    stat["stop_reason"] = "quick_limit" if mode == "quick" and take == limit and len(all_records) < max_records else "record_limit"
                elif stat["normalized"] < stat["received"]:
                    stat["stop_reason"] = "normalization_gap"
                elif finished or reached_total:
                    missing = known is not None and page.count_kind != "estimate" and len(seen_records[source]) < known
                    stat["complete"] = not missing and not stat["notes"]
                    stat["stop_reason"] = "count_mismatch" if missing else "exhausted"
                elif mode == "quick":
                    stat["stop_reason"] = "quick_limit"
                elif not unique_page:
                    stat["stop_reason"] = "repeated_page"
                else:
                    marker = repr(page.next_state)
                    # Crossref can reuse its opaque cursor while advancing rows.
                    # Repeated pages and the global budgets still stop loops.
                    if marker in seen_states[source] and source != "crossref":
                        stat["stop_reason"] = "repeated_cursor"
                    else:
                        seen_states[source].add(marker)
                        states[source] = page.next_state
                        again.append(source)
            active = again + [source for source in active if source not in batch]
    results = deduplicate(all_records)
    # Reciprocal rank avoids comparing incomparable database relevance scores.
    ranks = {}
    def rank_key(item):
        return (item["source"], tuple(sorted((item.get("ids") or {}).items())),
                item.get("title"), item.get("arxiv_version"))
    for item in all_records:
        ranks[rank_key(item)] = 1.0 / (60 + item.get("source_rank", 1))
    for item in results:
        source_scores = {}
        for evidence in item.get("source_records", []):
            source = evidence["source"]
            source_scores[source] = max(source_scores.get(source, 0), ranks.get(rank_key(evidence), 0))
        item["rank_score"] = sum(source_scores.values())
    if sort == "cited_by_count":
        # Counts remain attributed; never add counts from different indexes.
        priority = ("scopus", "semantic_scholar", "openalex", "crossref", "europepmc")
        def count_key(item):
            counts = item.get("citation_counts", {})
            source = next((s for s in priority if s in counts), None)
            item["citation_sort_source"] = source
            return counts[source]["count"] if source else -1
        results.sort(key=count_key, reverse=True)
    elif sort == "publication_date":
        results.sort(key=lambda r: r.get("publication_date") or str(r.get("year") or ""), reverse=True)
    else:
        results.sort(key=lambda r: r["rank_score"], reverse=True)
    totals = [s["reported_total"] for s in stats.values() if s["reported_total"] is not None]
    complete = all(s["complete"] for s in stats.values())
    return {"schema_version": "2.1", "query": query or "", "mode": mode, "accessed_at": utc_now(),
            "sources_queried": selected, "source_counts": stats,
            "total": sum(totals) if totals else 0,
            "total_semantics": "sum of reported database hits, overlapping; not unique papers; unknown totals omitted",
            "retrieved_count": sum(s["received"] for s in stats.values()),
            "retained_count": len(all_records), "unique_count": len(results), "result_count": len(results),
            "complete": complete, "completion_scope": "selected databases and executed queries only",
            "results": results, "errors": errors or None, "requests_used": client.calls,
            "provenance": client.provenance,
            "limits": {"max_records": max_records, "max_calls": max_calls, "quick_rows_per_source": limit},
            "notes": ["Citation sorting mixes explicitly attributed index counts; values are not directly equivalent"] if sort == "cited_by_count" and len(selected) > 1 else []}
