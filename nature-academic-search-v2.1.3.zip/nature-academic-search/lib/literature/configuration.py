"""Read provider settings without executing .env files or exporting their values."""
from __future__ import annotations

import configparser
import os
from pathlib import Path
import re
from threading import RLock

ENV_NAMES = frozenset({
    "OPENALEX_API_KEY", "OPENALEX_MAILTO", "S2_API_KEY", "SEMANTIC_SCHOLAR_API_KEY",
    "NCBI_API_KEY", "PUBMED_EMAIL", "CROSSREF_MAILTO", "UNPAYWALL_EMAIL", "CORE_API_KEY",
    "ELSEVIER_API_KEY", "ELSEVIER_INSTTOKEN", "PYBLIOMETRICS_CONFIG_FILE",
    "NATURE_ACADEMIC_SEARCH_CACHE_DIR",
})
_lock = RLock()
_file_cache = None


def _parse_dotenv(path):
    values = {}
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except (OSError, UnicodeError):
        raise ValueError("Could not read the literature .env file") from None
    for number, line in enumerate(lines, 1):
        match = re.match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", line)
        if not match or match[1] not in ENV_NAMES:
            continue
        name, value = match.groups()
        value = value.strip()
        if value.startswith(("'", '"')):
            delimiter, end = value[0], None
            escaped = False
            for index, char in enumerate(value[1:], 1):
                if char == delimiter and not escaped:
                    end = index
                    break
                escaped = delimiter == '"' and char == "\\" and not escaped
            if end is None or (value[end + 1:].strip() and not value[end + 1:].lstrip().startswith("#")):
                raise ValueError(f"Invalid quoted value in literature .env at line {number}")
            value = value[1:end]
            if delimiter == '"':
                escapes = {"n": "\n", "r": "\r", "t": "\t", '"': '"', "\\": "\\"}
                value = re.sub(r'\\([nrt"\\])', lambda m: escapes[m[1]], value)
        else:
            value = re.split(r"\s+#", value, maxsplit=1)[0].rstrip()
        values[name] = value
    return values


def dotenv_values():
    """Use an explicit file, or only .env in the current working directory."""
    explicit = os.environ.get("NATURE_ACADEMIC_SEARCH_ENV_FILE")
    path = Path(explicit).expanduser() if explicit else Path.cwd() / ".env"
    try:
        stamp = path.stat()
    except FileNotFoundError:
        if explicit:
            raise ValueError("NATURE_ACADEMIC_SEARCH_ENV_FILE does not exist") from None
        return {}
    except OSError:
        raise ValueError("Could not access the literature .env file") from None
    marker = (str(path.resolve()), stamp.st_mtime_ns, stamp.st_size)
    global _file_cache
    with _lock:
        if _file_cache is None or _file_cache[0] != marker:
            _file_cache = (marker, _parse_dotenv(path))
        return dict(_file_cache[1])


def environment_value(name, default="", *, aliases=()):
    """Process environment takes priority over the project's allowed settings."""
    names = (name, *aliases)
    for key in names:
        if os.environ.get(key):
            return os.environ[key]
    values = dotenv_values()
    return next((values[key] for key in names if values.get(key)), default)


def _configuration_path():
    explicit = environment_value("PYBLIOMETRICS_CONFIG_FILE")
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_file():
            raise ValueError("PYBLIOMETRICS_CONFIG_FILE does not name an existing file")
        return path
    candidates = [Path.home() / ".scopus/config.ini", Path.home() / ".pybliometrics/Scopus/config.ini",
                  Path.home() / ".config/pybliometrics.cfg", Path.home() / ".pybliometrics/config.ini"]
    return next((path for path in candidates if path.is_file()), None)


def elsevier_settings():
    """Return keys/tokens and legacy SDK settings in memory only.

    An overridden API key does not inherit a token belonging to an older key.
    Key and token lists use the SDK's comma-separated, corresponding-order form.
    """
    path = _configuration_path()
    config = configparser.ConfigParser(interpolation=None)
    config.optionxform = str
    if path:
        try:
            config.read_string(path.read_text(encoding="utf-8-sig"))
        except (configparser.Error, ValueError, OSError):
            raise ValueError("Could not parse the pybliometrics configuration") from None
    custom_keys = environment_value("ELSEVIER_API_KEY")
    custom_tokens = environment_value("ELSEVIER_INSTTOKEN")
    key_text = custom_keys or config.get("Authentication", "APIKey", fallback="")
    token_text = custom_tokens or (config.get("Authentication", "InstToken", fallback="") if not custom_keys else "")
    keys = [value.strip() for value in key_text.split(",") if value.strip()]
    tokens = [value.strip() for value in token_text.split(",") if value.strip()]
    if len(tokens) > len(keys):
        raise ValueError("Elsevier InstTokens must have corresponding API keys")
    return keys, tokens, config
