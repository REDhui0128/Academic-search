"""Shared retrieval helpers for nature-academic-search 2.1 (Python 3.10+)."""

__version__ = "2.1.3"
